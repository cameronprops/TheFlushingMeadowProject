#!/usr/bin/env python3
"""FMP Theme Center historical constraint solver and game-engine preflight.
Standard-library only; workbook Master_Facts is the authority, not guessed defaults.
"""
from __future__ import annotations
import argparse, json, math, posixpath, sys, zipfile
from datetime import datetime, timezone
from pathlib import Path
import xml.etree.ElementTree as ET

NS={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
P='http://schemas.openxmlformats.org/package/2006/relationships'
LOCKED={'F001':('Trylon height',610,'ft'),'F009':('Trylon frame transition',480,'ft'),'F010':('Trylon plate height',130,'ft'),'F012':('Trylon tip width',2+7/12,'ft'),'F021':('Perisphere diameter',180,'ft'),'F022':('Perisphere clearance',17,'ft'),'F023':('Perisphere columns',8,None),'F027':('Ring girder diameter',72,'ft'),'F028':('Meridian trusses',32,None),'F029':('Horizontal trusses',15,None),'F058':('Helicline length',950,'ft'),'F059':('Helicline width',18,'ft')}
ALLOWED={'VERIFIED_AS_BUILT','DERIVED_FROM_VERIFIED_AS_BUILT'}
FT_MM=304.8

def workbook_rows(path, sheet='Master_Facts'):
    """Read OOXML safely without a spreadsheet runtime. Formula caches are read, not executed."""
    with zipfile.ZipFile(path) as z:
        wb=ET.fromstring(z.read('xl/workbook.xml'))
        rel=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        targets={el.attrib['Id']:el.attrib['Target'] for el in rel}
        hit=next((s for s in wb.findall('m:sheets/m:sheet',NS) if s.attrib['name']==sheet),None)
        if hit is None: raise ValueError('Missing worksheet '+sheet)
        target=targets[hit.attrib['{%s}id'%NS['r']]]
        target=target.lstrip('/') if target.startswith('/') else posixpath.normpath(posixpath.join('xl',target))
        strings=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            st=ET.fromstring(z.read('xl/sharedStrings.xml'))
            strings=[''.join(n.text or '' for n in si.findall('.//m:t',NS)) for si in st.findall('m:si',NS)]
        root=ET.fromstring(z.read(target))
        rows=[]
        for row in root.findall('.//m:sheetData/m:row',NS):
            data={}
            for cell in row.findall('m:c',NS):
                addr=cell.attrib['r']; col=''.join(x for x in addr if x.isalpha()); idx=0
                for letter in col: idx=idx*26+ord(letter)-64
                v=cell.find('m:v',NS)
                if v is not None and v.text is not None:
                    value=v.text
                    if cell.attrib.get('t')=='s': value=strings[int(value)]
                    elif cell.attrib.get('t')=='b': value=value=='1'
                    else:
                        try: value=float(value)
                        except ValueError: pass
                else:
                    value=''.join(t.text or '' for t in cell.findall('.//m:is/m:t',NS)) or None
                data[idx-1]=value
            rows.append(data)
        if not rows: raise ValueError('Empty worksheet')
        cols=[rows[0].get(i) for i in range(max(rows[0])+1)]
        return [{name:row.get(i) for i,name in enumerate(cols) if name} for row in rows[1:] if row]

def numeric(v):
    if isinstance(v,bool) or v is None: return None
    try: return float(v)
    except (TypeError,ValueError): return None

def solve(facts, scale=120, game_units_per_meter=100):
    if scale<=0 or game_units_per_meter<=0: raise ValueError('Positive scale/game units required')
    byid={str(f.get('Fact_ID')):f for f in facts if f.get('Fact_ID')}
    errors=[]; warnings=[]; locked={}
    for fid,(label,expect,unit) in LOCKED.items():
        f=byid.get(fid)
        if not f: errors.append(f'{fid} missing: {label}'); continue
        value=numeric(f.get('Value'))
        if fid=='F012' and str(f.get('Value')).strip()=='2 ft 7 in': value=2+7/12
        if f.get('Status') not in ALLOWED or str(f.get('Code_Drive')).upper()!='YES':
            errors.append(f'{fid} unauthorized to drive final geometry'); continue
        if value is None or not math.isclose(value,expect,rel_tol=0,abs_tol=1e-6):
            errors.append(f'{fid} drift: expected {expect}, found {f.get("Value")}'); continue
        if unit and f.get('Unit')!=unit and not (fid=='F012' and f.get('Unit') is None and str(f.get('Value')).strip()=='2 ft 7 in'):
            errors.append(f'{fid} unit mismatch: {f.get("Unit")} != {unit}'); continue
        locked[fid]=value
    for fid in ('F047',):
        f=byid.get(fid)
        if f and str(f.get('Code_Drive')).upper()=='YES': errors.append(f'{fid} provisional entrance elevations cannot drive final geometry')
    # The workbook may store separate entrance rows, and their IDs can change.
    for f in facts:
        if f.get('Status') not in ALLOWED and str(f.get('Code_Drive')).upper()=='YES':
            errors.append(f'{f.get("Fact_ID")} is nonverified but Code_Drive=YES')
    result={'schema':'fmp.theme_center.solver.v1','input':{'scale_denominator':scale,'engine_units_per_meter':game_units_per_meter},'locked_inputs':locked,'errors':sorted(set(errors)),'warnings':warnings,'historical_final_allowed':not errors}
    if len(locked)==len(LOCKED):
        d=locked['F021']; h=locked['F001']; mer=locked['F028']; girder=locked['F027']; length=locked['F058']
        result['derived']={
          'trylon_plate_height_ft':locked['F001']-locked['F009'],
          'perisphere_radius_ft':d/2,
          'perisphere_center_height_ft':locked['F022']+d/2,
          'perisphere_top_height_ft':locked['F022']+d,
          'perisphere_equator_circumference_ft':math.pi*d,
          'meridian_angular_pitch_deg_IF_UNIFORMLY_SPACED':360/mer,
          'ring_girder_radius_ft':girder/2,
          'print_scale_trylon_height_mm':h*FT_MM/scale,
          'print_scale_perisphere_diameter_mm':d*FT_MM/scale,
          'print_scale_helicline_developed_length_mm':length*FT_MM/scale,
          'print_scale_helicline_width_mm':locked['F059']*FT_MM/scale}
        # Unreal-compatible metric transform, no claim of absolute site placement.
        factor=.3048*game_units_per_meter
        result['game_handoff']={'coordinate_frame':'THEME_CENTER_LOCAL','axis_convention':'X/Y horizontal, Z up','unreal_centimeters_per_foot':30.48,'trylon_height_cm':h*factor,'perisphere_diameter_cm':d*factor,'perisphere_center_z_cm':(locked['F022']+d/2)*factor,'bake_world_position':False,'bake_portals':False,'bake_helicline_alignment':False,'bake_sphere_and_tower_massing':not errors,'level_of_evidence':'VERIFIED DIMENSIONS; PLACEHOLDER PLACEMENT'}
    result['research_blockers']=[
      {'element':'TRYLON_BASE','reason':'Exact base footprint unresolved','action':'Keep geometry provisional'},
      {'element':'HELICLINE_SWEEP','reason':'Plan sweep and support spacing not verified','action':'Do not certify path as as-built'},
      {'element':'ENTRANCE_PORTALS','reason':'Entry elevations/bridge dimensions not verified','action':'Hold final bake and collision'},
      {'element':'PERISPHERE_TRUSS_STATIONS','reason':'Horizontal truss latitudes unknown','action':'Do not use uniform placement as history'},
      {'element':'FAIRGROUND_LOCATION','reason':'Absolute reference-frame transform not supplied','action':'Do not place in site world coordinates'}]
    return result

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('workbook',type=Path); ap.add_argument('--out',type=Path,default=Path('solver_report.json')); ap.add_argument('--scale',type=float,default=120)
    a=ap.parse_args(); report=solve(workbook_rows(a.workbook),scale=a.scale)
    a.out.parent.mkdir(parents=True,exist_ok=True); a.out.write_text(json.dumps(report,indent=2)+'\n')
    print('PASS' if report['historical_final_allowed'] else 'FAIL',len(report['errors']),'errors;',len(report['research_blockers']),'research blockers')
    return 0 if report['historical_final_allowed'] else 2
if __name__=='__main__':sys.exit(main())
