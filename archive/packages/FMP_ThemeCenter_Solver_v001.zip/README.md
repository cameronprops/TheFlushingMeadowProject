# FMP Theme Center Historical Constraint Solver v0.1

Runs against the included *BIM Ready* historical workbook. No third-party Python dependencies required.

## Execute

```bash
python3 theme_center_solver.py Trylon_Perisphere_Master_Point_of_Truth_BIM_Ready.xlsx --out solver_report.json
python3 -m unittest -v
```

Exit code **0** means the historical **numerical fact gate** passed; it does **not** mean all historical geometry has been validated, that all meshes are engine-ready, or that the Unreal build has passed.
Exit code **2** means the fact gate failed.

## Integration

- `solver_report.json` contains `locked_inputs`, `derived`, `research_blockers`, `errors`, and `game_handoff`.
- `game_handoff` uses Theme Center local coordinates and Unreal-compatible centimeters for the selected scalar dimensions.
- `bake_portals=false`, `bake_helicline_alignment=false`, and `bake_world_position=false` deliberately prevent treating unverified circulation and placement as finished historical geometry.
- For each game asset, store `TP_ElementID`, `SourceFactIDs`, `GeometryStatus`, and associated source version in its sidecar metadata. This first version does not yet generate geometry or export GLB/FBX/USD.
- `bake_sphere_and_tower_massing=true` means known major scalar dimensions are available for a **placeholder**. The Trylon base geometry and relative site placement remain unresolved. It is not an engine asset-admission certificate.

## Game Development Studio handoff

The Game Development Studio skill has been read. Its local `game-dev` executable was not available in this execution environment, so no asset vendoring, Blender normalization, GPU capture, or performance certification was run. The JSON is an **input** for future asset package checks, not a claim those checks passed. Any mutable `game-dev` invocation needs separate authorization of the exact command and destination.

## Scope and limitations

- The workbook is preserved verbatim in this package; the solver does not rewrite it.
- Current geometry rules cover 12 audited numeric facts and a handful of direct mathematical derivations.
- Unverified facts are not used in final numeric calculations. The code additionally rejects any workbook row marked `Code_Drive=YES` without a verified status.
- `F012` is the workbook's documented `2 ft 7 in` textual value, converted to feet.
- Evenly spaced meridian angle is explicitly conditional. It is not certified as-built placement.
- Absolute world coordinates, truss section geometry, structural safety, watertightness, collisions, mesh LOD, and game performance are NOT tested.
- Subsequent work: integrate the existing Theme Center preflight/engineering gate, add constraint interval solvers, element-by-element admission manifests, and numerical outputs for the Rhino builder.
