import unittest, copy
from pathlib import Path
from theme_center_solver import workbook_rows,solve
P=Path(__file__).resolve().parent/'Trylon_Perisphere_Master_Point_of_Truth_BIM_Ready.xlsx'
class SolverTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls): cls.facts=workbook_rows(P)
 def test_master(self):
  r=solve(self.facts); self.assertFalse(r['errors'],r['errors']); self.assertTrue(r['historical_final_allowed'])
 def test_height(self):
  r=solve(self.facts); self.assertAlmostEqual(r['derived']['print_scale_trylon_height_mm'],1549.4)
 def test_sphere(self):
  r=solve(self.facts); self.assertAlmostEqual(r['derived']['print_scale_perisphere_diameter_mm'],457.2)
 def test_tampered_dimension(self):
  f=copy.deepcopy(self.facts); next(x for x in f if x['Fact_ID']=='F001')['Value']=700
  self.assertFalse(solve(f)['historical_final_allowed'])
 def test_unverified_final_driver(self):
  f=copy.deepcopy(self.facts); f.append(dict(Fact_ID='TEST',Status='PROVISIONAL',Code_Drive='YES'))
  self.assertFalse(solve(f)['historical_final_allowed'])
 def test_game_gate(self):
  r=solve(self.facts); self.assertFalse(r['game_handoff']['bake_portals']); self.assertFalse(r['game_handoff']['bake_helicline_alignment']); self.assertAlmostEqual(r['game_handoff']['perisphere_diameter_cm'],5486.4)
if __name__=='__main__':unittest.main()
