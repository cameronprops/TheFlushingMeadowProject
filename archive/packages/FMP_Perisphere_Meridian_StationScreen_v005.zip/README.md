# FMP Perisphere Meridian mesh-to-period-station screen v005

**Status: Tested** against actual source SHA256 locked v005 GLB. Read-only. Original meshes untouched.

**Source runtime**: `FMP_ThemeCenter_Assembled_Runtime_v005.zip`, with embedded GLB SHA256 `de38fdd5294285afd92dbb6be0a9d4e564c52bacd588a9fd116c9e1e35f06439`.

**1939 period engineer**: Alfred J. Dillon, “Theme Center”, May 1939, reprinted at https://www.worldradiohistory.com/Archive-Broadcast-Engineers-Journal/ATE-1939-05.pdf. He reports meridian **truss** depth 11 ft bottom, 8 ft equator, 5 ft at top, along with support ring and bracing. These refer to truss radial/member construction, **NOT the ring girder's 8-ft vertical section**. The same article retains 700-ft/200-ft preliminary dimensions, so this remains a contemporaneous *design and engineering clue*, pending construction-sheet cross-check.

**New actual-model measurement**: Parsed the actual scene GLB, transformed each `Meridian_Truss_01` through `_32` to the local Y-up frame, and measured full radial vertex envelopes in two modeled near-equator Y ranges: [31.2,31.65] m and [33.45,33.8] m. The actual Perisphere nominal equator is at 32.6136 m, between these windows; no vertices lie within ±0.5 m of that exact plane. Across 32 meshes, the median near-equator envelope is 2.23882 m and 2.23967 m, respectively (~7.35 ft). Median Y separation between windows is 2.21676 m, so treat the two bands separately, not as exact cross-sectional plane samples.

**Important gate**: The mesh envelope includes member cross section and potentially diagonal web pieces. It is **NOT** a measured 1939 steel chord-to-chord depth or an exact 1939 as-built section. Near numerical agreement with 8 ft does NOT establish material geometry, node connectivity, or individual chord locations. No source master, optimized mesh, or print parts were changed. Native Unreal performance and Game Development Studio CLI validation not run.

## Reproduction

```
python audit_meridian_stations.py --zip /path/to/FMP_ThemeCenter_Assembled_Runtime_v005.zip --out REPORT.json
python -m unittest discover -p 'test_*.py' -v
```

The tests depend on the external unchanged v005 ZIP and will reject SHA drift. The package contains no redistributed third-party source scans or original 47 MB runtime GLB; those are already preserved as separately versioned Drive assets.

## Next geometrical increment

Derive distinct outer/inner meridian chord curves from editable mesh generators (not just triangles or radial extrema). Compare chord separation in planes normal to the meridian tangent at a documented station. Then cross-check 1938 construction photos and ASCE/engineering drawings before changing the historic steel master.
