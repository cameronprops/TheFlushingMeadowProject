"""Read-only model station screen, NOT a physical truss-depth measurement."""
import argparse, io, json, zipfile, hashlib
import numpy as np
import trimesh

def inspect(zip_path):
    with zipfile.ZipFile(zip_path) as z:
        name=next(x for x in z.namelist() if x.endswith('.glb'))
        data=z.read(name)
    digest=hashlib.sha256(data).hexdigest()
    expected='de38fdd5294285afd92dbb6be0a9d4e564c52bacd588a9fd116c9e1e35f06439'
    if digest!=expected: raise ValueError('SOURCE_GLB_HASH_MISMATCH')
    scene=trimesh.load(io.BytesIO(data),file_type='glb',force='scene',process=False)
    inner_window=(31.2,31.65) # model-local Y meters; these are sampled bands, not designed truss chords
    outer_window=(33.45,33.8)
    result=[]
    for i in range(1,33):
        n=f'Meridian_Truss_{i:02d}'
        if n not in scene.graph.nodes_geometry: raise ValueError('MISSING_MAIN_TRUSS_'+n)
        transform,geom=scene.graph[n]
        vertices=trimesh.transform_points(scene.geometry[geom].vertices,transform)
        r=np.hypot(vertices[:,0],vertices[:,2]); y=vertices[:,1]
        lo=(y>=inner_window[0])&(y<=inner_window[1]); hi=(y>=outer_window[0])&(y<=outer_window[1])
        if lo.sum()<3 or hi.sum()<3: raise ValueError('MISSING_STATION_SAMPLES_'+n)
        result.append({'node':n,'inner_band_r_median':float(np.median(r[lo])),
            'outer_band_r_median':float(np.median(r[hi])),
            'inner_band_radial_envelope_m':float(np.ptp(r[lo])),
            'outer_band_radial_envelope_m':float(np.ptp(r[hi])),
            'median_radial_shift_between_bands_m':float(np.median(r[hi])-np.median(r[lo])),
            'inner_band_y_median':float(np.median(y[lo])),
            'outer_band_y_median':float(np.median(y[hi])),
            'station_height_separation_m':float(np.median(y[hi])-np.median(y[lo])),
            'samples_inner':int(lo.sum()),'samples_outer':int(hi.sum())})
    rad=[p['inner_band_radial_envelope_m'] for p in result]
    rad2=[p['outer_band_radial_envelope_m'] for p in result]
    vertical=[p['station_height_separation_m'] for p in result]
    return {'schema':'fmp.runtime.truss.two-offset-stations.v001','status':'MODEL_VERTEX_SCREEN_ONLY',
        'source_asset':name,'source_glb_sha256':digest,'coordinate_frame':'model-local Y-up m',
        'sampled_nodes':32,'sampling_windows_y_m':[list(inner_window),list(outer_window)],
        'median_inner_band_radial_envelope_m':float(np.median(rad)),
        'median_outer_band_radial_envelope_m':float(np.median(rad2)),
        'radial_difference_range_m':[float(min(rad)),float(max(rad))],
        'median_vertical_station_difference_m':float(np.median(vertical)),
        'period_dillon_reference':'May 1939 A.J. Dillon article: meridian TRUSS depth 11ft bottom, 8ft equator, 5ft top. Article retains obsolete 700ft Trylon and 200ft shell.',
        'period_reference_equator_truss_depth_m':8*0.3048,
        'meridian_physical_depth_verified':False,
        'reason_not_physical_depth':'Both near-equator slices show ~2.24m total radial mesh envelope, including member thickness and possibly diagonal web elements. This is not necessarily the clear truss chord separation nor a surveyed historical chord depth. Two Y windows are separated by ~2.2m; no exact equator cross-section plane has enough vertex samples.',
        'geometry_accepted_asbuilt':False,'unreal_tested':False,'per_meridian':result}

if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('--zip',required=True);parser.add_argument('--out',required=True);a=parser.parse_args()
    result=inspect(a.zip)
    with open(a.out,'w') as f:json.dump(result,f,indent=2);f.write('\n')
    print(result['sampled_nodes'],result['median_inner_band_radial_envelope_m'],result['median_outer_band_radial_envelope_m'],result['median_vertical_station_difference_m'])
