import pathlib, unittest, json
from audit_meridian_stations import inspect
P=pathlib.Path(__file__).parent
SOURCE=pathlib.Path('/mnt/data/FMP_ThemeCenter_Assembled_Runtime_v005.zip')
class TestTrussScreen(unittest.TestCase):
 @classmethod
 def setUpClass(cls): cls.report=inspect(str(SOURCE))
 def test_count_32(self): self.assertEqual(self.report['sampled_nodes'],32)
 def test_all_two_stations(self): self.assertTrue(all(r['samples_inner']>2 and r['samples_outer']>2 for r in self.report['per_meridian']))
 def test_valid_envelope_consistency(self):
  r=self.report
  self.assertLess(r['radial_difference_range_m'][1]-r['radial_difference_range_m'][0],.05)
 def test_depth_not_certified(self): self.assertFalse(self.report['meridian_physical_depth_verified'])
 def test_no_historical_release(self): self.assertFalse(self.report['geometry_accepted_asbuilt'])
 def test_expected_glb_digest(self): self.assertEqual(self.report['source_glb_sha256'],'de38fdd5294285afd92dbb6be0a9d4e564c52bacd588a9fd116c9e1e35f06439')
if __name__=='__main__':unittest.main()
