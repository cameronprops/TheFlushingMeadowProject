#!/usr/bin/env python3
"""FMP WF0002 1938 girder photograph: source-aware metric-observability QA.

This does NOT solve historical depth or camera pose. It tests whether the existing
v002 hand-picked points are adequate to attempt perspective camera calibration.
No source image is downloaded or republished. Preserve raw v002 observations.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import cv2

SOURCE_URL = 'https://drivingfordeco.com/wp-content/uploads/2019/04/Drum-Girder.jpg'
SOURCE_IMAGE_SHA = '6d5fdba8ff455d0d10c44ed0a404cc318d80d128ac47b0f17d791cfdb860175c'

def ellipse_error(points, ellipse):
    xy,wh,theta=ellipse
    ang=np.deg2rad(theta)
    rot=np.array([[np.cos(ang),np.sin(ang)],[-np.sin(ang),np.cos(ang)]])
    u=(np.asarray(points)-np.asarray(xy))@rot.T
    normal=np.sqrt((u[:,0]/(wh[0]/2.0))**2+(u[:,1]/(wh[1]/2.0))**2)
    return (normal-1.0)*np.sqrt(wh[0]*wh[1])/2.0

def evaluate(obs):
    if obs.get('source_image_uri')!=SOURCE_URL or obs.get('decoded_pixel_sha256_wolfram')!=SOURCE_IMAGE_SHA:
        raise ValueError('source identity / decoded pixel hash must match registered photograph')
    if obs.get('image_size_px')!=[673,520]:raise ValueError('image size drift')
    top=np.asarray(obs['rim_points_px'],dtype=float)
    web=np.asarray(obs['visible_front_web_stiffener_pairs_px'],dtype=float)
    if top.ndim!=2 or top.shape[1]!=2 or len(top)<10 or not np.all(np.isfinite(top)):
        raise ValueError('insufficient finite rim points')
    if web.ndim!=3 or web.shape[1:]!=(2,2) or len(web)<4 or not np.all(np.isfinite(web)):
        raise ValueError('insufficient finite web pairs')
    if not np.all((top >= 0)&(top < [673,520])) or not np.all((web >= 0)&(web < [673,520])):
        raise ValueError('annotation outside source image')
    ellipse=cv2.fitEllipse(top.astype('float32'))
    in_fit=ellipse_error(top,ellipse)
    loo=[]
    for i in range(len(top)):
        leave=cv2.fitEllipse(np.delete(top,i,axis=0).astype('float32'))
        loo.append(float(ellipse_error(top[[i]],leave)[0]))
    heights=web[:,1,1]-web[:,0,1]
    dx=web[:,1,0]-web[:,0,0]
    if not np.all(heights>0): raise ValueError('web-pair ordering / identity invalid')
    all_x_locked=bool(np.all(np.abs(dx)<1e-10))
    # Regardless of pixel fit quality, these are *unmatched* observations:
    # 14 perimeter points lack 3D polar angle identifiers and 5 vertical pairs
    # were manually constrained to the same x. Actual K/R/t not identifiable.
    needs=[
      'Independent (not x-locked) upper/lower endpoints for each named physical stiffener',
      'Source-measured, documented correspondence and error for each rim point',
      'At least one second construction viewpoint or authenticated camera intrinsics/extrinsics',
      'Clarification whether 72 ft is ring centerline, inside or outside diameter',
      'Original negative/scan and exposure date/revision for photo authority']
    return {
      'schema':'fmp.wf0002.girder-photo-observability.v003',
      'source_uri':SOURCE_URL,'source_pixel_sha256':SOURCE_IMAGE_SHA,
      'status':'PHOTO_MEASUREMENT_QA_PASS_METRIC_CALIBRATION_BLOCKED',
      'pixel_frame':'673x520 x-right y-down',
      'rim_fit':{'method':'opencv_fitEllipse full sample plus leave-one-out',
                 'fit_count':len(top),'residual_rms_px':float(np.sqrt(np.mean(in_fit**2))),
                 'max_abs_residual_px':float(np.max(np.abs(in_fit))),
                 'loo_max_abs_residual_px':float(np.max(np.abs(loo))),
                 'loo_signed_residuals_px':[round(v,3) for v in loo],
                 'full_fit_ellipse_major_minor_px':sorted([float(v) for v in ellipse[1]],reverse=True)},
      'stiffener_pairs':{'count':len(web),'height_px':[float(x) for x in heights],
                       'height_median_px':float(np.median(heights)),
                       'delta_x_px':[float(x) for x in dx],
                       'all_pairs_exact_x_locked':all_x_locked,
                       'usable_to_recover_vertical_vanishing_point':not all_x_locked},
      'camera_calibration':{'known_3d_rim_azimuth_correspondences':0,
                            'independently_measured_stiffener_3d_2d_correspondences':0,
                            'known_intrinsics':False,'camera_pose_solved':False,
                            'physical_depth_solved':False,
                            'note':'Apparent circular rim alone constrains a conic, not a unique unknown pinhole camera + depth.'},
      'hypothesis_screen':'v002 gain scenarios only, not calibrated or probability distribution',
      'evidence_class':'PROVISIONAL_PHOTO_ANNOTATION',
      'runtime_geometry_mutation_allowed':False,
      'source_photo_bytes_redistributed':False,
      'new_source_requirements':needs,
    }

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--observations',required=True)
    parser.add_argument('--out',required=True)
    args=parser.parse_args()
    report=evaluate(json.loads(Path(args.observations).read_text()))
    Path(args.out).write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
    print('QA',report['status'],'max LOO px',report['rim_fit']['loo_max_abs_residual_px'])

if __name__=='__main__':main()
