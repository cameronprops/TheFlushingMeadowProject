import copy
import json
import unittest
from pathlib import Path
from audit_girder_photo_observability_v003 import evaluate

SOURCE=json.loads((Path(__file__).parent/'PHOTO_ANNOTATIONS_v002.json').read_text())
class Checks(unittest.TestCase):
    def test_live_annotated_photo(self):
        r=evaluate(SOURCE)
        self.assertEqual(r['status'],'PHOTO_MEASUREMENT_QA_PASS_METRIC_CALIBRATION_BLOCKED')
        self.assertEqual(r['rim_fit']['fit_count'],14)
    def test_rim_loo_positive(self):
        self.assertGreater(evaluate(SOURCE)['rim_fit']['loo_max_abs_residual_px'],10)
    def test_locked_x_identified(self):
        self.assertTrue(evaluate(SOURCE)['stiffener_pairs']['all_pairs_exact_x_locked'])
    def test_no_camera_pose(self):
        self.assertFalse(evaluate(SOURCE)['camera_calibration']['camera_pose_solved'])
    def test_no_geometry_mutation(self):
        self.assertFalse(evaluate(SOURCE)['runtime_geometry_mutation_allowed'])
    def test_hash_refusal(self):
        d=copy.deepcopy(SOURCE);d['decoded_pixel_sha256_wolfram']='wrong'
        with self.assertRaises(ValueError):evaluate(d)
    def test_bounds_refusal(self):
        d=copy.deepcopy(SOURCE);d['rim_points_px'][2]=[1000,10]
        with self.assertRaises(ValueError):evaluate(d)
    def test_nonfinite_refusal(self):
        d=copy.deepcopy(SOURCE);d['rim_points_px'][2]=[float('nan'),10]
        with self.assertRaises(ValueError):evaluate(d)
    def test_short_rim_refusal(self):
        d=copy.deepcopy(SOURCE);d['rim_points_px']=d['rim_points_px'][:4]
        with self.assertRaises(ValueError):evaluate(d)
    def test_web_order_refusal(self):
        d=copy.deepcopy(SOURCE);d['visible_front_web_stiffener_pairs_px'][0]=[[40,400],[40,200]]
        with self.assertRaises(ValueError):evaluate(d)
    def test_different_x_does_not_automatically_certify(self):
        d=copy.deepcopy(SOURCE);d['visible_front_web_stiffener_pairs_px'][0][1][0]+=1
        r=evaluate(d)
        self.assertFalse(r['stiffener_pairs']['all_pairs_exact_x_locked'])
        self.assertFalse(r['camera_calibration']['camera_pose_solved'])

if __name__=='__main__':unittest.main()
