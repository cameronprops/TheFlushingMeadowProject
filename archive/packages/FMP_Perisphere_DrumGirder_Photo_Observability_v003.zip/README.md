# FMP WF0002: Drum-girder photo observability audit v003

**Status: Implemented/tested QA; camera calibration blocked; historical geometry unchanged.**

## What this adds beyond v002

The preceding 1938 riveted drum photograph study used a 14-point ellipse and 5 hand-placed web/stiffener span pairs, producing conditional depth scenarios consistent with an approximately 8-ft structural drum. This release **audits the informational content of those exact original measurements** before any new camera or steel geometry is claimed.

Read-only tests on the original v002 annotation JSON show:
- All **14** ellipse rim picks are used; approximate ellipse radial residual **4.990 px RMS** and **9.135 px** maximum absolute residual.
- Single-point leave-one-out prediction maximum approximate radial residual **14.544 px**. This is not a statistical confidence interval. The outliers show the 14 points do not lie perfectly on one projected ideal circle, and edge identity/occlusion matter.
- The five visible front-face spans are **74, 78, 81, 84, 88 px**, median **81 px**. Their top and bottom observations all have **exactly the same image x coordinate** because of the annotation method (`delta_x=0` by construction), not independently recovered matching vertical vanishing points. The full 3D correspondence count remains **zero**.
- A 2D ellipse plus artificially x-locked web pairs **cannot uniquely recover focal length, camera distance, world pose or physical girder depth**, even if the earlier conditional gain estimate looks compatible with the period article. The v002 6.4–10.2-ft *scenario outputs* are sensitivity examples, not a justified depth uncertainty interval.

## Historical provenance

- Primary design text: November 1938 *Architectural Record* describes 32 meridian trusses, the 72-ft diameter, 8-ft-deep ring girder and eight supporting columns. https://www.usmodernist.org/AR/AR-1938-11.pdf (period reporting; also has obsolete preliminary Trylon figures elsewhere).
- Photograph: 1938-era construction image republished at https://drivingfordeco.com/wp-content/uploads/2019/04/Drum-Girder.jpg ; decoded 673×520 pixels in Wolfram, hash `6d5fdba8ff455d0d10c44ed0a404cc318d80d128ac47b0f17d791cfdb860175c`. Original negative/camera metadata unknown. **No photographic pixels in this package.** Rights remain unresolved.
- v005 mesh audit: `Perisphere_Support_Ring` toroidal proxy estimated tube section 0.396 m/1.299 ft, approximately 72-ft centerline ring. Do not equate the torus to the original load-bearing drum before checking editable source; issue #21.

## Reproduce

From this folder, using Python + NumPy/OpenCV:

```sh
python audit_girder_photo_observability_v003.py --observations PHOTO_ANNOTATIONS_v002.json --out PHOTO_QA_REPORT_v003.json
python -m unittest -q test_girder_photo_observability_v003.py
```

**Results:** 11/11 automated tests passed locally, and Wolfram independently reproduced 4.989948 px ellipse RMS, 9.135 px max and median 81 px web height. No source/model geometry was changed.

## Next admissible measurement

1. Retrieve archival original-quality negative/scan and capture multiple genuinely corresponding upper/lower endpoints for the **same steel stiffeners**, including their natural x offsets, source crop coordinates, and uncertainty.
2. Establish *which* 72-ft ring reference was documented—outer, inner or centerline—and differentiate flange, web and temporary erection radial members.
3. Obtain at least a second independent viewpoint or calibrated intrinsics; solve the real metric pinhole camera and inspect independent holdout reprojection errors, condition number, uncertainty bounds and ambiguity.
4. Only after corroboration add a **separate** editable 8-ft girder candidate, preserving the original historic masters and runtime support ring. No game/Unreal admission performed.

**Not certified:** period dimensions as-built, photograph exposure date, camera, depth, true stiffener points, Trylon/Helicline structural nodes, printed objects.
