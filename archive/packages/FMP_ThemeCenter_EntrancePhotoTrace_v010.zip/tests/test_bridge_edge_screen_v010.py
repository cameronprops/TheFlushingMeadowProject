import copy, json, unittest
from pathlib import Path
from tools.bridge_edge_screen_v010 import screen,EvidenceError

SRC=Path(__file__).resolve().parents[1]/'research'/'GOTTSCHO_BRIDGE_EDGE_ANNOTATIONS_v010.json'

class BridgeTraceTest(unittest.TestCase):
    def setUp(self): self.raw=json.loads(SRC.read_text())
    def test_actual_screen(self):
        r=screen(self.raw);self.assertEqual(r['accepted_screen_only_points'],5)
        self.assertLess(r['max_loo_error_px'],3)
    def test_no_geometry_release(self): self.assertFalse(screen(self.raw)['historical_geometry_release_allowed'])
    def test_exact_source_hash(self):
        self.raw['source']['wolfram_decoded_pixel_array_sha256']='x'*64
        with self.assertRaises(EvidenceError):screen(self.raw)
    def test_dimensions(self):
        self.raw['source']['working_image_dimensions_px']=[1920,2354]
        with self.assertRaises(EvidenceError):screen(self.raw)
    def test_no_fictitious_original_download(self):
        self.raw['source']['verified_source_original_binary_archived']=True
        with self.assertRaises(EvidenceError):screen(self.raw)
    def test_no_fake_camera(self):
        self.raw['source']['source_camera_calibrated']=True
        with self.assertRaises(EvidenceError):screen(self.raw)
    def test_out_of_bounds(self):
        self.raw['measurement']['points'][1]['picked_y']=1200
        with self.assertRaises(EvidenceError):screen(self.raw)
    def test_search_window(self):
        self.raw['measurement']['points'][1]['picked_y']=900
        with self.assertRaises(EvidenceError):screen(self.raw)
    def test_duplicate(self):
        self.raw['measurement']['points'][4]['x']=640
        with self.assertRaises(EvidenceError):screen(self.raw)
    def test_weak_edge_cannot_be_accepted(self):
        self.raw['measurement']['points'][1]['edge_gradient']=0.2
        with self.assertRaises(EvidenceError):screen(self.raw)
    def test_wrong_control_set(self):
        self.raw['measurement']['points'][6]['status']='ACCEPTED_SCREEN_ONLY'
        with self.assertRaises(EvidenceError):screen(self.raw)
    def test_curve_outlier_rejected(self):
        self.raw['measurement']['points'][3]['picked_y']=821
        self.raw['measurement']['points'][3]['guess_y']=821
        with self.assertRaises(EvidenceError):screen(self.raw)
    def test_does_not_claim_jambs(self): self.assertEqual(screen(self.raw)['photo_jamb_count_measured'],0)
    def test_rejected_not_used(self):
        self.raw['measurement']['points'][0]['picked_y']+=1
        self.assertEqual(screen(self.raw)['accepted_screen_only_points'],5)

if __name__=='__main__':unittest.main()
