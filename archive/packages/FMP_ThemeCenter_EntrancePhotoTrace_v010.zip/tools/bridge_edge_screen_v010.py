"""Deterministic SCREEN-SPACE screening of real Gottscho bridge image edge picks.

Source image pixel detection performed on 960x1177 CC0 thumbnail in Wolfram;
this script validates the source-locked serialized 13 candidates and *does not*
claim camera calibration or a physical 3D bridge reconstruction.
"""
import argparse, json, math
from pathlib import Path
import numpy as np

EXPECTED_PIXEL_ARRAY_SHA256 = '4b618f1f2531684e0e35006cf0f775f3cef5d6ae7160787c002ae4f5e41a5777'

class EvidenceError(ValueError):
    pass

def screen(record):
    s=record['source']; m=record['measurement']; w,h=s['working_image_dimensions_px']
    if (w,h)!=(960,1177) or s['wolfram_decoded_pixel_array_sha256']!=EXPECTED_PIXEL_ARRAY_SHA256:
        raise EvidenceError('Authenticated image identity / dimensions mismatch')
    if s['source_camera_calibrated'] or s['verified_source_original_binary_archived']:
        raise EvidenceError('This evidence record cannot claim an unperformed source acquisition or pose')
    pts=m['points']; xs=[p['x'] for p in pts]
    if len(pts)!=13 or len(xs)!=len(set(xs)):
        raise EvidenceError('Missing or duplicated original photo edge picks')
    for p in pts:
        if not (0<=p['x']<w and 0<=p['picked_y']<h and 0<=p['guess_y']<h):
            raise EvidenceError('Pixel out of original source bounds')
        if abs(p['picked_y']-p['guess_y'])>m['y_search_half_range_px']:
            raise EvidenceError('Picked pixel outside declared Wolfram scanning window')
        if not (0<=p['edge_gradient']<=1):
            raise EvidenceError('Invalid normalized grayscale gradient')
    good=[p for p in pts if p['status']=='ACCEPTED_SCREEN_ONLY']
    if len(good)!=5 or [p['x'] for p in good]!=[600,620,640,660,680]:
        raise EvidenceError('Accepted bridge segment differs from visually screened evidence')
    if any(p['edge_gradient']<.35 for p in good):
        raise EvidenceError('Underside edge candidates below declared quality threshold')
    x=np.array([p['x'] for p in good],dtype=float)
    y=np.array([p['picked_y'] for p in good],dtype=float)
    # centered coordinates make the local polynomial stable and inspectable
    centered=(x-640.)/20.
    c=np.polyfit(centered,y,2)
    fitted=np.polyval(c,centered)
    residuals=y-fitted
    loo=[]
    for i in range(len(x)):
        mask=np.arange(len(x))!=i
        candidate=np.polyfit(centered[mask],y[mask],2)
        loo.append(float(y[i]-np.polyval(candidate,centered[i])))
    max_loo=max(map(abs,loo))
    if max_loo>3 or m['historical_geometry_release_allowed']:
        raise EvidenceError('Photo-screen fit rejected or attempted to promote historical geometry')
    return {
        'schema':'fmp.theme-center.gottscho-bridge-2d-edge-screen.v010',
        'status':'PROVISIONAL_2D_UNDERSIDE_CURVE_ONLY',
        'image_pixel_array_sha256':EXPECTED_PIXEL_ARRAY_SHA256,
        'evidence_points_total':len(pts),
        'accepted_screen_only_points':len(good),
        'rejected_or_review_points':len(pts)-len(good),
        'observed_x_domain_px':[600,680],
        'accepted_xy_px':x.astype(int).tolist() and [[int(a),int(b)] for a,b in zip(x,y)],
        'local_quadratic':'y = a*t^2 + b*t + c; t=(x-640)/20; valid only over observed domain',
        'coefficients_a_b_c_px':c.tolist(),
        'training_rmse_px':float(math.sqrt(np.mean(residuals**2))),
        'max_loo_error_px':max_loo,
        'loo_errors_px':loo,
        'photo_jamb_count_measured':0,
        'world_control_points_measured':0,
        'camera_pose_estimated':False,
        'bridge_3d_curvature_certified':False,
        'historical_geometry_release_allowed':False,
        'model_changed':False,
        'limitations':['Curve is projected 2D photo edge only. Strong perspective distortion and other camera unknowns.',
                       'Five accepted samples cover only 80 pixels of the full 960px photo.',
                       'Edges were found inside manual prediction windows and are NOT independent model fit controls.',
                       'No physical bridge geometry, entrance jamb, bridge elevation, or 3 inch accuracy can be claimed.']
    }

def run(src,dest):
    report=screen(json.loads(Path(src).read_text()))
    Path(dest).write_text(json.dumps(report,indent=2)+'\n')
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('source_json');p.add_argument('report_json');a=p.parse_args()
    print(json.dumps(run(a.source_json,a.report_json),indent=2))
