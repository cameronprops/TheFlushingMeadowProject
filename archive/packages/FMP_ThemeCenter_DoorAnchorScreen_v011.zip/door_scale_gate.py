"""Evidence-only relative door proportions from RIBA 9908 image; no 3D release."""
import json, math, sys
from pathlib import Path

EXPECTED_RIBA_PIXEL_HASH = 'e1ae067b4bbfced3bc31407d1610b322c9197cc5f3360246d530d91e65af29d2'
EXPECTED_NYPL_PIXEL_HASH = '91a52b7962db3c21789baf32b7ff09edba6442e750445f3e30966881dade6679'


def screen(record):
    assert record['schema'] == 'fmp.theme-center.lower-exit-aperture-observation.v011'
    s1, s2 = record['sources']
    assert s1['id'] == 'RIBA9908_SECONDARY' and s1['pixel_dimensions'] == [647,1000]
    assert s1['wolfram_decoded_pixel_sha256'] == EXPECTED_RIBA_PIXEL_HASH
    assert s2['wolfram_decoded_pixel_sha256'] == EXPECTED_NYPL_PIXEL_HASH
    assert s2['id'] == 'NYPL_A654_SECONDARY' and s2['pixel_dimensions'] == [582,730]
    assert s1['feature_id'] != s2['feature_id']
    assert s1['lower_threshold_visible'] is False and s1['door_leaf_identified'] is False
    assert s2['matching_3d_features_to_riba'] == 0
    assert record['historically_verified_door_width_in'] is None
    assert record['historically_verified_door_height_in'] is None
    assert record['actual_camera_calibrated'] is False and record['geometry_release_allowed'] is False
    p = s1['points_xy_px']; dim = s1['pixel_dimensions']
    assert set(p) == {'head_left','head_right','visible_left_at_balustrade','visible_right_at_balustrade'}
    for xy in p.values():
        assert len(xy)==2 and all(isinstance(z,(int,float)) and math.isfinite(z) for z in xy)
        assert 0 <= xy[0] < dim[0] and 0 <= xy[1] < dim[1]
    midpoint = lambda a,b: [(a[0]+b[0])/2, (a[1]+b[1])/2]
    width = math.dist(p['head_left'], p['head_right'])
    visible = math.dist(midpoint(p['head_left'],p['head_right']),
                        midpoint(p['visible_left_at_balustrade'],p['visible_right_at_balustrade']))
    assert 10 <= width <= 100 and visible > 0
    result=[]
    for wh in record['door_scale_hypotheses_in']:
        w,h=wh
        if not (20<=w<=60 and 72<=h<=96): raise ValueError('Out-of-domain illustration')
        full = width*h/w  # Only under equal projected scale in doorway plane.
        fraction = visible/full
        result.append({'hypothetical_width_in':w,'hypothetical_height_in':h,
                       'predicted_projected_full_height_px':round(full,5),
                       'visible_fraction_under_equal_scale':round(fraction,5),
                       'would_require_unobserved_lower_portion':fraction<1})
    return {'status':'PARTIAL_APERTURE_IMAGE_PLANE_ONLY',
            'feature_id':s1['feature_id'],
            'observed_head_width_px':round(width,5),
            'observed_head_to_balustrade_midpoint_px':round(visible,5),
            'candidate_standard_sizes':result,
            'all_scenarios_require_occluded_door_lower_portion':all(x['would_require_unobserved_lower_portion'] for x in result),
            'physical_door_dimensions_recovered':False,
            'two_view_registration_solved':False,
            'history_1939_geometry_release_allowed':False,
            'model_changes_authorized':False,
            'notes':['Do not treat pixel correspondence or nominal modern door standards as inch-level calibration.',
                     'Second NYPL photograph shows a different bridge-end aperture group, not a validated stereo match.',
                     'Visible opening may function as lower Perisphere exit; service-door identity not established.',
                     'Partial face projects differently along Y and X; nominal scenarios ignore camera distortion.']}

if __name__=='__main__':
    src=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('annotations.json')
    out=Path(sys.argv[2]) if len(sys.argv)>2 else None
    contents=json.dumps(screen(json.loads(src.read_text())),indent=2)+'\n'
    if out:out.write_text(contents)
    else:print(contents)
