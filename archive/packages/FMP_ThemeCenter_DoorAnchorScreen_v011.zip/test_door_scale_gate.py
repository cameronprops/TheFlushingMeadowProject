import copy, json, unittest
from pathlib import Path
from door_scale_gate import screen

INPUT=json.loads(Path(__file__).with_name('annotations.json').read_text())

class TestDoorScreen(unittest.TestCase):
    def test_partial_only(self):self.assertEqual(screen(INPUT)['status'],'PARTIAL_APERTURE_IMAGE_PLANE_ONLY')
    def test_width(self):self.assertAlmostEqual(screen(INPUT)['observed_head_width_px'],30.26549,4)
    def test_visible_section(self):self.assertAlmostEqual(screen(INPUT)['observed_head_to_balustrade_midpoint_px'],35.8922,4)
    def test_36_by_80(self):
        x=screen(INPUT)['candidate_standard_sizes'][2]
        self.assertAlmostEqual(x['predicted_projected_full_height_px'],67.25665,4)
        self.assertAlmostEqual(x['visible_fraction_under_equal_scale'],.53366,4)
    def test_every_scenario_is_hidden(self):self.assertTrue(screen(INPUT)['all_scenarios_require_occluded_door_lower_portion'])
    def test_no_historical_permission(self):self.assertFalse(screen(INPUT)['history_1939_geometry_release_allowed'])
    def test_bad_image_hash(self):
        x=copy.deepcopy(INPUT);x['sources'][0]['wolfram_decoded_pixel_sha256']='0'*64
        with self.assertRaises(AssertionError):screen(x)
    def test_door_size_unverified(self):
        x=copy.deepcopy(INPUT);x['historically_verified_door_width_in']=36
        with self.assertRaises(AssertionError):screen(x)
    def test_threshold_disallowed(self):
        x=copy.deepcopy(INPUT);x['sources'][0]['lower_threshold_visible']=True
        with self.assertRaises(AssertionError):screen(x)
    def test_no_false_two_photo_match(self):
        x=copy.deepcopy(INPUT);x['sources'][1]['matching_3d_features_to_riba']=4
        with self.assertRaises(AssertionError):screen(x)
    def test_wrong_feature_id(self):
        x=copy.deepcopy(INPUT);x['sources'][1]['feature_id']=x['sources'][0]['feature_id']
        with self.assertRaises(AssertionError):screen(x)
    def test_outside_pixels(self):
        x=copy.deepcopy(INPUT);x['sources'][0]['points_xy_px']['head_left']=[10000,350]
        with self.assertRaises(AssertionError):screen(x)

if __name__=='__main__':unittest.main()
