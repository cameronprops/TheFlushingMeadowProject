import importlib.util
from pathlib import Path
import math
import unittest

MOD = Path(__file__).resolve().parents[1]/"tools"/"entrance_stair_gate_v009.py"
SPEC=importlib.util.spec_from_file_location("entrance_gate",MOD)
G=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(G)

class EntranceTests(unittest.TestCase):
  def setUp(self):
    self.input=dict(model_upper_y_m=19.431,model_bridge_y_m=15.74292,
      modeled_risers=23,modeled_rise_m=0.15902610447095794,
      modeled_going_m=0.29662197376411714,
      preliminary_upper_ft=64,preliminary_lower_ft=52)
  def test_difference(self):
    self.assertEqual(G.model_stair_screen(self.input)["provisional_documentary_level_difference_ft"],12)
  def test_23_risers_nominal(self):
    self.assertAlmostEqual(G.model_stair_screen(self.input)["modeled_each_riser_in"],6.26087,places=4)
  def test_model_levels_not_identical(self):
    self.assertAlmostEqual(G.model_stair_screen(self.input)["model_minus_documentary_height_in"],1.2,places=5)
  def test_model_riser_total_does_not_auto_approve(self):
    self.assertFalse(G.model_stair_screen(self.input)["historical_geometry_release_allowed"])
  def test_22_riser_candidate(self):
    cs=G.candidate_risers(12,22,22);self.assertAlmostEqual(cs[0]["riser_in"],6.545455,places=5)
  def test_invalid_level(self):
    self.input["model_upper_y_m"]=10
    with self.assertRaises(ValueError):G.model_stair_screen(self.input)
  def test_invalid_height(self):
    with self.assertRaises(ValueError):G.candidate_risers(float("nan"))
  def test_uncertainty_missing(self):
    self.assertFalse(G.error_budget_95pct(dict(control=0.0))["pass"])
  def test_uncertainty_bounded(self):
    vals=dict.fromkeys(("control","camera","source","annotation","model"),0.005)
    self.assertTrue(G.error_budget_95pct(vals)["pass"])
  def test_uncertainty_too_big(self):
    vals=dict.fromkeys(("control","camera","source","annotation","model"),0.03)
    self.assertFalse(G.error_budget_95pct(vals)["pass"])
  def test_uncertainty_invalid_nan(self):
    vals=dict.fromkeys(("control","camera","source","annotation","model"),float("nan"))
    self.assertFalse(G.error_budget_95pct(vals)["pass"])
  def test_approval_missing_rejected(self):
    self.assertFalse(G.geometry_admission({})["admit"])
  def test_approval_even_if_all_true_is_review_only(self):
    vals=dict.fromkeys(("control","camera","source","annotation","model"),0.002)
    b=G.error_budget_95pct(vals)
    data=dict(survey_control_registered=True,asbuilt_level_evidence=True,
     independent_camera_holdouts=True,door_edge_identified=True,
     stair_clearance_screened=True,x_budget=b,y_budget=b,z_budget=b)
    result=G.geometry_admission(data)
    self.assertTrue(result["ready_for_independent_review"])
    self.assertFalse(result["admit"])

if __name__=='__main__': unittest.main()
