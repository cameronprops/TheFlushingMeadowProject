"""Non-mutating Theme Center entrance / stair constraint and precision gate.

Inputs are archival hypothesis plus v008 model known measurements.
This is a RESEARCH gate. It cannot certify historical as-built stairs or a code-compliant stair.
"""
from __future__ import annotations
from dataclasses import dataclass
import json
import math
from pathlib import Path

FT_M = 0.3048
IN_M = 0.0254


def candidate_risers(total_rise_ft: float, min_count: int = 20, max_count: int = 26):
    if not math.isfinite(total_rise_ft) or total_rise_ft <= 0 or min_count < 1 or max_count < min_count:
        raise ValueError("invalid rise or candidate counts")
    return [{"risers": n, "riser_in": round(total_rise_ft * 12 / n, 6)}
            for n in range(min_count, max_count + 1)]


def model_stair_screen(report: dict) -> dict:
    """Screen legacy *provisional* stair against a preliminary two-level hypothesis."""
    u, l = report["model_upper_y_m"], report["model_bridge_y_m"]
    if not all(map(math.isfinite, [u, l])) or u <= l:
        raise ValueError("invalid physical level order")
    n = report["modeled_risers"]
    rise = report["modeled_rise_m"]
    go = report["modeled_going_m"]
    if not isinstance(n, int) or n <= 0 or min(rise, go) <= 0:
        raise ValueError("invalid stair")
    preliminary = report["preliminary_upper_ft"] - report["preliminary_lower_ft"]
    if preliminary <= 0: raise ValueError("invalid documentary height order")
    return {
        "schema":"fmp.stair-readonly-screen.v009",
        "provisional_documentary_level_difference_ft":preliminary,
        "model_level_difference_in":round((u-l)/IN_M,6),
        "model_minus_documentary_height_in":round((u-l)/IN_M-12*preliminary,6),
        "modeled_riser_count":n,
        "modeled_each_riser_in":round(rise/IN_M,6),
        "modeled_each_going_in":round(go/IN_M,6),
        "modeled_total_riser_height_in":round(n*rise/IN_M,6),
        "modeled_vs_model_landing_height_in":round((n*rise-(u-l))/IN_M,6),
        "stair_angle_deg":round(math.degrees(math.atan2(rise,go)),6),
        "riser_candidates":candidate_risers(preliminary,20,25),
        "historical_stair_count_certified":False,
        "continuous_swept_body_clearance_certified":False,
        "native_unreal_walkthrough_certified":False,
        "historical_geometry_release_allowed":False,
        "physical_precision_gate":"BLOCKED_NO_INDEPENDENT_SURVEYED_CONTROLS"
    }


def error_budget_95pct(components_m: dict, threshold_in: float=3.0) -> dict:
    """Conservative sum of full-axis 95% bounds. Unknown is a hard refusal.
    Do not use as a statistical confidence estimator: assumes worst-case bounds.
    """
    names=("control","camera","source","annotation","model")
    if not all(k in components_m for k in names):
        return {"status":"MISSING_UNCERTAINTY_COMPONENTS", "pass":False}
    vals=[components_m[k] for k in names]
    if not all(isinstance(v,(int,float)) and math.isfinite(v) and v>=0 for v in vals):
        return {"status":"INVALID_UNCERTAINTY", "pass":False}
    value=sum(vals)/IN_M
    return {"status":"BOUNDED" if value<=threshold_in else "EXCEEDS_TARGET",
            "upper_bound_in":round(value,6),"target_in":threshold_in,
            "pass":value<=threshold_in}


def geometry_admission(confidence: dict) -> dict:
    required=("survey_control_registered","asbuilt_level_evidence","independent_camera_holdouts",
              "door_edge_identified","stair_clearance_screened","x_budget","y_budget","z_budget")
    if not all(k in confidence for k in required):
        return {"status":"MISSING_ADMISSION_FIELDS", "admit":False}
    axes=all(isinstance(confidence[k],dict) and confidence[k].get("pass") is True for k in ("x_budget","y_budget","z_budget"))
    gates=all(confidence[k] is True for k in required[:5])
    return {"status":"DERIVED_CANDIDATE_REVIEW_REQUIRED" if gates and axes else "BLOCKED",
            "admit":False,
            "ready_for_independent_review":gates and axes,
            "historical_geometry_release_allowed":False}


if __name__ == "__main__":
    d={"model_upper_y_m":19.431,"model_bridge_y_m":15.74292,
       "modeled_risers":23,"modeled_rise_m":0.15902610447095794,
       "modeled_going_m":0.29662197376411714,
       "preliminary_upper_ft":64,"preliminary_lower_ft":52}
    print(json.dumps(model_stair_screen(d),indent=2))
