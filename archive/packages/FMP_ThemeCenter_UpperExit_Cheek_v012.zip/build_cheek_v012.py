"""Read-only source-locked, reversible candidate cheekwall overlay for v005 23-step upper exit stair.
A physical interpretation of the *presence* of the sloped solid stair cheek seen in RIBA9908.
NOT a source-derived wall thickness, plane, profile, side selection or historical location.
"""
from __future__ import annotations
import argparse, hashlib, io, json, zipfile
from pathlib import Path
import numpy as np
import trimesh
SOURCE_SHA='de38fdd5294285afd92dbb6be0a9d4e564c52bacd588a9fd116c9e1e35f06439'
SOURCE_MEMBER='FMP_ThemeCenter_Assembled_Runtime_v005.glb'
STAIR_PREFIX='PROVISIONAL_UpperReturnStair_'
LEGACY='PROVISIONAL_UPPER_EXIT_STAIR'
GATE='PROVISIONAL_RUNTIME_OVERLAY_NOT_HISTORIC'

def load_source(path):
    with zipfile.ZipFile(path) as z: data=z.read(SOURCE_MEMBER)
    sha=hashlib.sha256(data).hexdigest()
    if sha!=SOURCE_SHA:raise ValueError('Wrong original GLB hash: '+sha)
    return trimesh.load(io.BytesIO(data),file_type='glb',force='scene',process=False)

def world_mesh(scene,name):
    if name not in scene.graph.nodes_geometry:raise ValueError('Missing node '+name)
    t,gn=scene.graph[name];m=scene.geometry[gn].copy();m.apply_transform(t);return m

def stats(scene):
    meshes=[world_mesh(scene,STAIR_PREFIX+str(i).zfill(2)) for i in range(1,24)]
    centers=np.array([m.bounds.mean(0) for m in meshes])
    centers[:,1]=np.array([m.bounds[1,1] for m in meshes])
    delta=centers[-1]-centers[0]
    horiz=np.array([delta[0],0.,delta[2]]); horiz/=np.linalg.norm(horiz)
    lateral=np.array([-horiz[2],0.,horiz[0]])
    legacy=world_mesh(scene,LEGACY)
    upper=world_mesh(scene,'PROVISIONAL_UpperLandingToStair')
    portal=world_mesh(scene,'INTERPRETIVE_UPPER_PORTAL_HEAD')
    lower=world_mesh(scene,'INTERPRETIVE_LOWER_PORTAL_HEAD')
    extrema=np.array([m.bounds for m in meshes])
    stair_bounds=np.vstack([extrema[:,0,:].min(0),extrema[:,1,:].max(0)])
    distance=max(0.,max(stair_bounds[0,0],legacy.bounds[0,0])-min(stair_bounds[1,0],legacy.bounds[1,0]))
    # This is separation of AXIS ALIGNED BOUNDS, not Euclidean mesh-to-mesh distance.
    return dict(meshes=meshes,centers=centers,along=horiz,across=lateral,legacy=legacy,
                upper=upper,portal=portal,lower=lower,stair_bounds=stair_bounds,
                x_gap=distance)

def build_wall(centers,across,offset=1.045,thickness=.10,top_guard=1.0,bridge_y=15.8496,side=1):
    if side not in (-1,1):raise ValueError('side must be +1 or -1')
    if not (offset>0.925 and .05<=thickness<=.25 and .7<=top_guard<=1.3):
        raise ValueError('Candidate wall outside declared safe/test limits')
    # Extend at upper/lower end by half a going. This is an editorial/simplified mesh choice.
    d=centers[-1]-centers[0];d[1]=0;d=d/np.linalg.norm(d)
    first=centers[0]-d*.16;last=centers[-1]+d*.16
    points=np.vstack([first,centers,last]);
    # The top profile approximates stair slope + GUARD; bottom is fixed bridge elevation.
    tops=np.r_[centers[0,1]+top_guard,centers[:,1]+top_guard,centers[-1,1]+top_guard]
    bottom=min(bridge_y-.12,float(np.min(tops))-.20)
    # Two close side surfaces with end strips triangulated, watertight two-manifold polyhedron.
    v=[]
    for layer in [0,1]:
        a=side*(offset + layer*thickness)*across
        for row,p in enumerate(points):
            v.append([p[0]+a[0],bottom,p[2]+a[2]])
            v.append([p[0]+a[0],tops[row],p[2]+a[2]])
    v=np.asarray(v,dtype=float); N=len(points);faces=[]
    for j in range(N-1):
        b=2*j; c=b+2
        faces += [[b,c,b+1],[b+1,c,c+1]]  # near face
        d=2*N
        faces += [[d+b,d+b+1,d+c],[d+b+1,d+c+1,d+c]] # far
        faces += [[b,d+b,c],[c,d+b,d+c]] # bottom rail
        faces += [[b+1,c+1,d+b+1],[d+b+1,c+1,d+c+1]] # top rail
    far=2*N
    faces += [[0,1,far],[far,1,far+1]]
    end=2*(N-1)
    faces += [[end,far+end,end+1],[end+1,far+end,far+end+1]]
    mesh=trimesh.Trimesh(vertices=v,faces=faces,process=True)
    mesh.fix_normals()
    return mesh,dict(offset_m=offset,thickness_m=thickness,guard_above_tread_m=top_guard,
                     bottom_y_m=bottom,side_selector=side,step_count=len(centers))

def run(input_zip,outdir,side=1):
    sc=load_source(input_zip);s=stats(sc)
    mesh,pars=build_wall(s['centers'],s['across'],side=side)
    if not mesh.is_watertight or not mesh.is_winding_consistent or not mesh.is_volume:
        raise ValueError('Generated sidewall is not a closed manifold volume')
    # Sidewall horizontal separation from stair *centerline*: by construction >half stair width.
    wall_center_dist=pars['offset_m']
    report={
      'schema':'fmp.theme-center.upper-exit-cheek.v012',
      'status':GATE, 'source_glb_sha256':SOURCE_SHA,
      'source_model_local':'METRES_Y_UP_UNREGISTERED',
      'historical_3d_location_verified':False,
      'mesh_source_modified':False,
      'legacy_stair':'PROVISIONAL_UPPER_EXIT_STAIR',
      'legacy_stair_world_bbox_m':s['legacy'].bounds.round(8).tolist(),
      '23_tread_stair_world_bbox_m':s['stair_bounds'].round(8).tolist(),
      'legacy_vs_23_tread_x_bbox_gap_m':round(s['x_gap'],8),
      'upper_portal_head_bbox_m':s['portal'].bounds.round(8).tolist(),
      'landing_bbox_m':s['upper'].bounds.round(8).tolist(),
      'candidate_cheek_bbox_m':mesh.bounds.round(8).tolist(),
      'candidate_mesh_triangles':len(mesh.faces),
      'candidate_watertight':mesh.is_watertight,
      'candidate_winding_consistent':mesh.is_winding_consistent,
      'tread_top_center_y_m':s['centers'][:,1].round(8).tolist(),
      'tread_top_mean_rise_m':float(np.mean(-np.diff(s['centers'][:,1]))),
      'physical_photo_confirms':'solid triangular/sloped sidewall beside upper Perisphere exit stair',
      'photo_source':'RIBA9908.jpg, secondary 647x1000, photographer/copyright unresolved; image itself not republished',
      'photo_does_not_confirm':['side of stair','wall thickness','wall footing y','1m guard','step count','wall endpoints','door width'],
      'parms':pars,
      'clearance':'UNTESTED_NATIVE_ENGINE_AND_SWEPT_VOLUME',
      'legacy_duplicate_resolution':'BLOCKED_SOURCE_AND_SURVEY_REVIEW; both stair systems retained in originals',
      'release_for_master':False
    }
    outdir.mkdir(parents=True,exist_ok=True)
    scene=trimesh.Scene();scene.add_geometry(mesh,geom_name='PROVISIONAL_WF0002_UPPER_EXIT_STAIR_CHEEK_A_v012')
    result=outdir/'FMP_Upper_Exit_Stair_Cheek_Overlay_v012.glb';scene.export(result)
    report['overlay_file']=result.name
    report['overlay_sha256']=hashlib.sha256(result.read_bytes()).hexdigest()
    (outdir/'MODEL_AUDIT_v012.json').write_text(json.dumps(report,indent=2)+'\n')
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source-zip',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--side',type=int,choices=[-1,1],default=1);a=p.parse_args()
    r=run(a.source_zip,a.output,a.side);print(json.dumps({k:r[k] for k in ['status','legacy_vs_23_tread_x_bbox_gap_m','candidate_watertight','candidate_mesh_triangles','overlay_sha256']},indent=2))
