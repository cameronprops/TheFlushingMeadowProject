"""Actual model geometry technical side-elevation, not a historic photograph."""
import zipfile,io,hashlib,numpy as np,trimesh,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path
from build_cheek_v012 import load_source,stats,build_wall
root=Path(__file__).parent
scene=load_source(Path('/mnt/data/FMP_ThemeCenter_Assembled_Runtime_v005.zip'))
st=stats(scene)
centers=st['centers'];first=centers[0];d=st['along'];
s=(centers-first)@d
wall,params=build_wall(centers,st['across'])
# Keep only side profile from source-generated walls (local longitudinal coordinate)
wv=wall.vertices
u=(wv-first)@d
fig,ax=plt.subplots(figsize=(11,6))
ax.fill_between([u.min(),u.max()],params['bottom_y_m'],[centers[0,1]+params['guard_above_tread_m'],centers[-1,1]+params['guard_above_tread_m']],alpha=.22,label='Candidate solid sidewall (provisional)')
ax.plot(s,centers[:,1],'o-',markersize=3,label='Existing 23 tread top heights (actual v005 GLB)')
ax.plot(s,centers[:,1]+params['guard_above_tread_m'],linestyle='--',label='Provisional 1 m guard profile')
ax.axhline(15.8496,linestyle=':',label='v005 return-bridge top ≈15.8496 m')
ax.set_xlabel('Distance down stair from first tread (m), model-local')
ax.set_ylabel('Elevation Y (m), model-local; not surveyed')
ax.set_title('FMP Theme Center — Upper exit stair cheek candidate v012\nCode-derived from the exact assembled v005 GLB; NOT as-built dimensions')
ax.legend(loc='upper right',fontsize=8)
ax.grid(alpha=.15)
fig.tight_layout()
fig.savefig(root/'STAIR_CHEEK_SIDE_ELEVATION_v012.svg')
fig.savefig(root/'STAIR_CHEEK_SIDE_ELEVATION_v012.png',dpi=135)
plt.close(fig)
print('wrote side elevation')
