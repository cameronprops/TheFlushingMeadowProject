# Theme Center upper exit stair sidewall / conflict audit v012

**Status:** Implemented, 15 unit tests passed, but **PROVISIONAL RUNTIME OVERLAY ONLY**. This is a code-generated candidate from actual existing model mesh coordinates. Not a newly measured 1939 architectural dimension or accepted printable master.

## What the photographed sources actually show

The historical RIBApix image `RIBA9908.jpg` (secondary 647×1000 reproduced through Driving for Deco) shows (1) an upper Perisphere exit stair descending along a **solid triangular white sidewall** to the return bridge, and (2) a separate opening at deck level beneath/alongside the stair. The lower opening's architectural function is provisionally *lower public exit* rather than established service door, but its sill is occluded by the glass balustrade. The original RIBA catalog negative and any as-built doorway schedule have NOT been acquired; source photo pixels have not been republished here. The complementary NYPL-attributed bridge photograph `5e66b3e8-a654-d471-e040-e00a180654d7` shows another opening group at the opposite end of the bridge, NOT an authenticated matched view of the same door.

The 1939 Gottscho photograph of the external bridge has a smooth, curved external soffit; **this candidate stair cheek is not a replacement for the bridge's exterior soffit or historic canopy**. Source photographic dimensions, true side selection, materials, wall thickness, base elevation, end attachments and number of historic stair steps all remain unresolved.

A *newly identified* archival acquisition lead is the Harry Ransom Center (UT Austin) 1939 Samuel Gottscho portfolio, original print **`980:0151:0007`, titled `[Perisphere bridge, trylon and ramp]`**, in catalog record [PH-00789](https://research.hrc.utexas.edu/photoPublic/fullDisplay.cfm?CollID=16343). **Metadata only** — image not examined or calibrated. This could help independent plan/bridge registration, but it must not be treated as a successful stereo source.

The RIBA image rights remain restricted under RIBA's licensing; only source metadata and independent re-created 3D interpretation are archived.

## Actual v005 mesh discrepancy

Input: `/mnt/data/FMP_ThemeCenter_Assembled_Runtime_v005.zip`, `FMP_ThemeCenter_Assembled_Runtime_v005.glb`, **SHA256 de38fdd5294285afd92dbb6be0a9d4e564c52bacd588a9fd116c9e1e35f06439**; project-local right-handed Y-up metres, unregistered. Input archive and original master unchanged.

The scene has two non-overlapping upper-stair candidates:

- **Legacy `PROVISIONAL_UPPER_EXIT_STAIR`**: AABB x ≈ **−22.499 to −17.226 m**; 344 triangles.
- **Separate 23 objects `PROVISIONAL_UpperReturnStair_01..23`**: combined AABB x ≈ **−30.934 to −24.016 m**; 23x12 triangles. Their X bounds are separated by **1.517 m** (≈59.73 in). Those models do not describe the same stair-space in the current scene. The newer 23-tread approach intersects the upper landing's X envelope; the legacy mesh does not intersect the upper portal-head X envelope.

This is a **current-runtime inconsistency**, not a claim the historic fair had two stairs or proof which mesh is correct. Both remain in original source. Do **not** delete the legacy mesh without an additional scene traversal/architecture review.

## Generator and provisional overlay

`build_cheek_v012.py` extracts the exact 23 tread mesh world transforms, computes the stair longitudinal/lateral basis, and constructs a watertight, 196-triangle **separate GLB** representing an approximate solid triangular sidewall to a bridge-height datum. It uses **candidate** 1.045m lateral offset, 0.10m wall thickness, 1.0m guard height, and bridge-height anchor y=15.8496m. Those numbers are **modern editorial assumptions**, not measurements in RIBA9908. Side=+1 selects the nominal exposed/outboard side; side=-1 is a reversible test alternative. Neither version is in historical master.

The separate GLB **must be loaded as an overlay into the existing world**, never as a replacement for v005/v008. The source stair mesh is retained; no historical elevation, portal position or stair count changed.

### Tests

From package directory with `numpy`, `trimesh`, `scipy`: `python -m unittest discover -s . -p 'test_cheek_v012.py' -v`.

15 tests PASS: SHA lock, actual 23 treads, decreasing step elevations, approximately 159mm modeled rises, 1.517m candidate X disjunction, no historical metadata promotion, manifold winding and positive volume, surface offset beyond current tread sides, source unchanged, rejected unsafe options, alternative side reversible.

A separate scripted side-elevation SVG/PNG shows **actual modeled stair top heights plus the provisional wall silhouette**, not a generated historic photograph. Renderer unavailable in native Unreal; scene-wide capsule swept-volume collisions, portal wall intersection/attachment, matching real photo camera and guardrail historic dimensions are still **NOT TESTED**.

### Next concrete work

1. Obtain HRC photo 980:0151:0007 and original RIBA image/catalog metadata; identify same fixed bridge joints and Perisphere jambs across viewpoints.
2. Calibrate 1939 site facade/door and true stair side selection with independently surveyed architectural references and 2 heldout features per image.
3. Inspect legacy `PROVISIONAL_UPPER_EXIT_STAIR` separate from later 23-step stair and identify intended role. Reconcile *without* overwriting source history.
4. Register photo-derived wall orientation, endpoints/guard height; perform genuine swept head/body clearance and native Unreal traversal. Only then integrate an as-built revision.

**Evidence class:** Image-sidewall occurrence **verified visually**; v005 dimensions **derived from runtime**; world-located wall shape **provisional**; all as-built dimensional claims **blocked**.
