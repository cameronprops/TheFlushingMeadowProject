"""Bounded source-locked regression checks; no claim of historical truth or Unreal acceptance."""
import hashlib, io, sys, unittest, zipfile
from pathlib import Path
import numpy as np,trimesh
from build_cheek_v012 import load_source,stats,build_wall,run,SOURCE_SHA,GATE
ROOT=Path(__file__).parent
ZIP=Path('/mnt/data/FMP_ThemeCenter_Assembled_Runtime_v005.zip')

class StairCheekTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.scene=load_source(ZIP);cls.s=stats(cls.scene)
  cls.wall,cls.settings=build_wall(cls.s['centers'],cls.s['across'])
 def test_expected_source_sha(self):
  with zipfile.ZipFile(ZIP) as z: b=z.read('FMP_ThemeCenter_Assembled_Runtime_v005.glb')
  self.assertEqual(hashlib.sha256(b).hexdigest(),SOURCE_SHA)
 def test_23_stairs_not_an_assumed_count(self):self.assertEqual(len(self.s['meshes']),23)
 def test_stairs_top_to_bottom(self):self.assertTrue(np.all(np.diff(self.s['centers'][:,1])<0))
 def test_stair_bay_rise_consistent(self):self.assertAlmostEqual(float(np.mean(-np.diff(self.s['centers'][:,1]))),.1590261,places=5)
 def test_legacy_conflict(self):self.assertAlmostEqual(self.s['x_gap'],1.51712418,places=5)
 def test_photo_is_not_metric_calibration(self):
  report=run(ZIP,ROOT)
  self.assertEqual(report['status'],GATE)
  self.assertFalse(report['historical_3d_location_verified'])
  self.assertFalse(report['release_for_master'])
 def test_watertight(self):self.assertTrue(self.wall.is_watertight)
 def test_winding(self):self.assertTrue(self.wall.is_winding_consistent)
 def test_positive_volume(self):self.assertGreater(self.wall.volume,0)
 def test_sidewall_outside_stair_tread(self):self.assertGreater(self.settings['offset_m']-.05,.925)
 def test_sidewall_stays_separate_from_legacy_x_bbox(self):self.assertGreater(self.s['legacy'].bounds[0,0]-self.wall.bounds[1,0],0)
 def test_source_geometry_not_overwritten(self):
  self.assertEqual(hashlib.sha256((ROOT/'FMP_Upper_Exit_Stair_Cheek_Overlay_v012.glb').read_bytes()).hexdigest(),run(ZIP,ROOT)['overlay_sha256'])
 def test_reject_bad_side(self):
  with self.assertRaises(ValueError):build_wall(self.s['centers'],self.s['across'],side=0)
 def test_reject_doorwidth_assumption(self):
  with self.assertRaises(ValueError):build_wall(self.s['centers'],self.s['across'],offset=.90)
 def test_alternative_side_is_reversible(self):
  other,_=build_wall(self.s['centers'],self.s['across'],side=-1)
  self.assertTrue(other.is_watertight)
  self.assertNotAlmostEqual(other.bounds[0,0],self.wall.bounds[0,0],places=2)
if __name__=='__main__':unittest.main(verbosity=2)
