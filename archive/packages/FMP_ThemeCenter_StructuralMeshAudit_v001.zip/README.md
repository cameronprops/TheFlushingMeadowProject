# FMP Theme Center runtime structural mesh audit v001

**Status:** Tested read-only audit of the actual `FMP_ThemeCenter_Assembled_Runtime_v005.glb`.
**Date:** 2026-10-21
**Source:** Google Drive [assembled runtime v005](https://drive.google.com/file/d/1OzFZRkHCxN3jMBGwH3Lwdbx0pFJIJhM0/view)
**GLB SHA-256:** `de38fdd5294285afd92dbb6be0a9d4e564c52bacd588a9fd116c9e1e35f06439`
**Geometry frame:** metres; local Y-up, not surveyed or georeferenced.

## Actual mesh observations
- 573 scene graph nodes, 32 `Meridian_Truss_XX`, 15 `Latitude_Truss_XX`, and 8 `Perisphere_Column_XX` mesh nodes.
- Trylon face 1 and face 2 contain 156 disjoint 32-triangle member-like mesh components each.
- The portal-modified third face has 160 components of 28, 30, or 32 triangles; these are **runtime geometry pieces**, not a researched engineering material schedule.
- Trylon face 1 has 38 repeated interior heights at approximately 3.75138 m increments within the 146.304 m / 480 ft lower-frame section, implying 39 **equally spaced modeled** panels. Period evidence of approximately 39 column lengths does not establish historically equal bays.
- `Helicline_Single_Column_Proxies` contains 17 disconnected 32-triangle cylinders. Their Y-up local plan centres and apparent top elevations are in `REPORT.json` as **provisional model coordinates**, not verified construction footings.

## Verification
Run against the archived source ZIP:

    python audit_theme_center_structural_mesh_v001.py --zip /path/to/FMP_ThemeCenter_Assembled_Runtime_v005.zip --out REPORT.json
    python test_audit_theme_center_structural_mesh_v001.py -q

Executed against the 47,126,840-byte verified GLB: audit PASS and **4/4 unit tests PASS**. A nonfatal spreadsheet-plugin startup warning from the Python environment was unrelated to these tests. ZIP inputs and original GLB were not rewritten.

## Admission limits
- This is *what the existing runtime contains*, not proof that those members or their stations match 1938–1939 steel drawings.
- No measured photo-to-model control points, exact Trylon historical bay schedule, historically located Helicline column foundations, or Perisphere latitude station schedule have been established.
- `game-dev` CLI was not installed locally, and native Unreal import/collision/playability were **not** tested.
- Source references are external archival photographs/films whose rights must be cleared before redistributing scan bytes. No third-party photograph is packaged.

The next useful test is to compare these model-local candidate geometry features against registered dated construction photos and original engineering sheets, rather than to rebuild meshes from placeholders.
