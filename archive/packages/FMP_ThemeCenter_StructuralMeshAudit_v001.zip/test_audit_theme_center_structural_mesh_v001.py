import importlib.util
from pathlib import Path
import json
import sys
import unittest
root=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("a",root/"audit_theme_center_structural_mesh_v001.py")
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)

class EvidenceGateTests(unittest.TestCase):
    def test_expected_sha_rejects_wrong_bytes(self):
        with self.assertRaisesRegex(ValueError,"GLB_SHA256_MISMATCH"):
            a.validate_model_bytes(b"deliberately wrong")
    def test_expected_sha_accepts_known_bytes(self):
        raw=a.ASSET.encode() # not correct GLB; tests separate expected digest contract
        with self.assertRaises(ValueError):a.validate_model_bytes(raw)
    def test_readonly_metadata(self):
        if not hasattr(self,"model"):return
        r=self.model
        self.assertFalse(r["historical_controls"]["as_built_geometry_release_allowed"])
        self.assertFalse(r["runtime_controls"]["unreal_import_passed"])
    def test_real_glb_if_available(self):
        z=Path('/mnt/data/FMP_ThemeCenter_Assembled_Runtime_v005.zip')
        if not z.exists():self.skipTest('archived runtime not mounted')
        scene,sha=a.get_assembly(z);r=a.audit_scene(scene,sha)
        self.assertEqual(r['input_scene_node_count'],573)
        self.assertEqual(r['modeled_perisphere']['main_meridian_truss_nodes'],32)
        self.assertEqual(r['modeled_perisphere']['latitude_truss_nodes'],15)
        self.assertEqual(r['modeled_perisphere']['support_column_nodes'],8)
        self.assertEqual(len(r['modeled_trylon']['face_1_repeated_interior_y_stations_m']),38)
        self.assertEqual(r['modeled_trylon']['uniform_lower_bay_count_model_hypothesis'],39)
        self.assertEqual(r['modeled_helicline']['proxy_count'],17)
        self.assertTrue(r['modeled_helicline']['all_proxies_32_triangles'])
        self.assertFalse(r['historical_controls']['trylon_bay_elevations_verified'])
        self.assertFalse(r['historical_controls']['helicline_column_locations_verified'])
        self.assertFalse(r['runtime_controls']['asset_normalized_or_modified'])
if __name__=='__main__':unittest.main()
