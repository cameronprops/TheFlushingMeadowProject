#!/usr/bin/env python3
"""Evidence-safe, read-only audit of Theme Center v005 runtime geometry.

This counts *modeled* steel elements. It cannot establish as-built truss stations,
Helicline footing locations, or any camera/world registration.
Requires numpy and trimesh; preserves source ZIP and GLB exactly.
"""
import argparse
from collections import Counter
import hashlib
import io
import json
from pathlib import Path
import re
import zipfile

import numpy as np
import trimesh

ASSET = "FMP_ThemeCenter_Assembled_Runtime_v005.glb"
EXPECTED_SHA256 = "de38fdd5294285afd92dbb6be0a9d4e564c52bacd588a9fd116c9e1e35f06439"


def validate_model_bytes(blob, sha=EXPECTED_SHA256):
    actual = hashlib.sha256(blob).hexdigest()
    if actual != sha:
        raise ValueError(f"GLB_SHA256_MISMATCH expected={sha} actual={actual}")
    return actual


def get_assembly(zip_path):
    with zipfile.ZipFile(zip_path) as z:
        if z.testzip() is not None:
            raise ValueError("ZIP_CRC_FAILURE")
        data = z.read(ASSET)
    source_sha = validate_model_bytes(data)
    return trimesh.load(io.BytesIO(data), file_type="glb", force="scene"), source_sha


def node_mesh(scene, name):
    if name not in scene.graph.nodes:
        raise ValueError(f"MISSING_NODE:{name}")
    xform, mesh_id = scene.graph[name]
    if mesh_id is None:
        return None, None
    return trimesh.Trimesh(vertices=trimesh.transform_points(scene.geometry[mesh_id].vertices,xform),
                           faces=scene.geometry[mesh_id].faces, process=False), mesh_id


def connected_parts(mesh):
    return list(trimesh.graph.connected_components(mesh.face_adjacency,
                     nodes=np.arange(len(mesh.faces),dtype=np.int64)))


def inspect_node(scene, name):
    mesh, mesh_id = node_mesh(scene,name)
    if mesh is None:
        return {"node":name,"mesh_bound":False,"triangles":0}
    comps = connected_parts(mesh)
    return {"node":name,"mesh_bound":True,"mesh_id":mesh_id,
            "triangle_count":int(len(mesh.faces)),"vertex_count":int(len(mesh.vertices)),
            "connected_piece_count":len(comps),"triangles_per_piece":sorted(set(map(len,comps))),
            "bounds_xyz_m":[mesh.bounds[0].tolist(),mesh.bounds[1].tolist()]}


def audit_scene(scene, glb_sha):
    all_names = list(map(str,scene.graph.nodes))
    meridians=sorted(n for n in all_names if re.fullmatch(r"Meridian_Truss_\d\d",n))
    latitudes=sorted(n for n in all_names if re.fullmatch(r"Latitude_Truss_\d\d",n))
    columns=sorted(n for n in all_names if re.fullmatch(r"Perisphere_Column_\d\d",n))
    if (len(meridians),len(latitudes),len(columns))!=(32,15,8):
        raise ValueError(f"MODELED_GRID_COUNT_DIFFERENCE:{len(meridians)}, {len(latitudes)}, {len(columns)}")
    frames=["Trylon_Face_1_Frame","Trylon_Face_2_Frame",
            "Trylon_Face_3_Frame__RUNTIME_SHARED_APERTURES_v004"]
    frame_nodes=[inspect_node(scene,n) for n in frames]
    first,_=node_mesh(scene,frames[0]); counts=Counter(np.round(first.vertices[:,1],3))
    interior=np.array(sorted([float(k) for k,num in counts.items() if num>=10 and 0<k<146.304]))
    # This identifies the repeated station peaks in the *mesh*, not historical elevations.
    nominal=np.arange(1,39)*146.304/39
    if len(interior)!=38 or np.max(np.abs(interior-nominal))>0.002:
        raise ValueError("MODEL_TRYLON_EQUAL_STATIONS_DIFFER_FROM_DOCUMENTED_V005_PATTERN")
    heli_name="Helicline_Single_Column_Proxies"
    heli, _=node_mesh(scene,heli_name)
    parts=connected_parts(heli)
    heli_cols=[]
    for faces in parts:
        vertices=heli.vertices[np.unique(heli.faces[faces].ravel())]
        b0=vertices.min(axis=0);b1=vertices.max(axis=0)
        heli_cols.append({"center_plan_xz_m":[float((b0[0]+b1[0])/2),float((b0[2]+b1[2])/2)],
            "modeled_top_y_m":float(b1[1]),"modeled_base_y_m":float(b0[1]),"triangles":int(len(faces))})
    heli_cols=sorted(heli_cols,key=lambda x:x["modeled_top_y_m"],reverse=True)
    return {"schema":"fmp.theme-center.runtime-structural-model-audit.v001",
        "status":"READ_ONLY_RUNTIME_GEOMETRY_OBSERVED_NOT_HISTORICALLY_CERTIFIED",
        "asset":ASSET,"asset_sha256":glb_sha,"coordinate_frame":"model-local, Y-up, metres, nongeoreferenced",
        "input_scene_node_count":len(all_names),
        "modeled_perisphere":{"main_meridian_truss_nodes":len(meridians),
           "latitude_truss_nodes":len(latitudes),"support_column_nodes":len(columns),
           "support_ring":inspect_node(scene,"Perisphere_Support_Ring"),
           "sample_meridian":inspect_node(scene,"Meridian_Truss_01"),
           "sample_latitude":inspect_node(scene,"Latitude_Truss_01")},
        "modeled_trylon":{"face_nodes":frame_nodes,
            "face_1_repeated_interior_y_stations_m":interior.tolist(),
            "uniform_lower_bay_count_model_hypothesis":39,
            "uniform_lower_bay_rise_model_m":float(146.304/39),
            "station_fit_max_error_m_due_to_rounding":float(np.max(np.abs(interior-nominal))),
            "lower_frame_transition_m_documented":146.304,
            "historical_uniformity_established":False},
        "modeled_helicline":{"node":heli_name,"proxy_count":len(parts),
            "all_proxies_32_triangles":bool(all(len(p)==32 for p in parts)),
            "column_geometry_centers_model_local_provisional":heli_cols,
            "historical_footings_established":False},
        "historical_controls":{"truss_station_heights_verified":False,
            "trylon_bay_elevations_verified":False,"helicline_column_locations_verified":False,
            "independent_photo_registration_done":False,
            "as_built_geometry_release_allowed":False},
        "runtime_controls":{"unreal_import_passed":False,"collision_navigation_passed":False,
            "asset_normalized_or_modified":False}}


def main():
    ap=argparse.ArgumentParser();ap.add_argument("--zip",required=True,type=Path)
    ap.add_argument("--out",required=True,type=Path)
    args=ap.parse_args();scene,checksum=get_assembly(args.zip)
    report=audit_scene(scene,checksum)
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
    print(f"PASS Runtime {checksum[:12]}: 32+15 truss nodes, 8 sphere columns, 39 equal modeled Trylon bays, 17 Helicline proxies")
    print("HISTORICAL_STATUS: not certified; no model file changed")

if __name__=="__main__":main()
