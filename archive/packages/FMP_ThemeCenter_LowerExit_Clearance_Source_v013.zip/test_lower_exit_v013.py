import io
import json
import os
from pathlib import Path
import unittest
import zipfile
import trimesh
from repair_lower_exit_v013 import (SOURCE_SHA256,LEGACY,sha,chunks,unpack_json,patch_source,rebuild_glb)
from check_lower_exit_v013 import section_screen

DIR=Path(__file__).parent
SRC=Path(os.environ.get('FMP_V005_ZIP','/mnt/data/FMP_ThemeCenter_Assembled_Runtime_v005.zip'))
DERIVED=DIR/'FMP_ThemeCenter_Runtime_LowerExit_Clear_v013.glb'

class RuntimeSelectionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with zipfile.ZipFile(SRC) as f:cls.original=f.read('FMP_ThemeCenter_Assembled_Runtime_v005.glb')
        cls.derived=DERIVED.read_bytes()

    def test_source_locked(self):self.assertEqual(sha(self.original),SOURCE_SHA256)
    def test_gltf_format(self):self.assertEqual(chunks(self.derived)[0][0],b'JSON')
    def test_binary_payload_is_identical(self):self.assertEqual(chunks(self.derived)[1][1],chunks(self.original)[1][1])
    def test_nodes_not_deleted(self):self.assertEqual(len(unpack_json(self.original)['nodes']),len(unpack_json(self.derived)['nodes']))
    def test_meshes_not_deleted(self):self.assertEqual(len(unpack_json(self.original)['meshes']),len(unpack_json(self.derived)['meshes']))
    def test_old_mesh_binding_only_disabled(self):
        a=unpack_json(self.original)['nodes'];b=unpack_json(self.derived)['nodes'];self.assertEqual(a[498]['mesh'],643);self.assertNotIn('mesh',b[498])
    def test_other_node_binding_unchanged(self):
        a=unpack_json(self.original)['nodes'];b=unpack_json(self.derived)['nodes'];self.assertEqual([x.get('mesh') for i,x in enumerate(a) if i!=498],[x.get('mesh') for i,x in enumerate(b) if i!=498])
    def test_23_new_treads_remain(self):
        nodes=unpack_json(self.derived)['nodes'];self.assertEqual(23,sum(x.get('name','').startswith('PROVISIONAL_UpperReturnStair_') and x.get('mesh') is not None for x in nodes))
    def test_wrong_sha_fails(self):
        b=bytearray(self.original);b[-8]^=1
        with self.assertRaisesRegex(ValueError,'wrong model source'):patch_source(bytes(b))
    def test_patch_is_deterministic(self):self.assertEqual(patch_source(self.original)[0],self.derived)
    def test_still_trimesh_loadable(self):
        s=trimesh.load(io.BytesIO(self.derived),file_type='glb',force='scene');self.assertIsNone(s.graph.get(LEGACY)[1])
    def test_13_before_sections_intruded(self):
        a=section_screen(self.original);self.assertEqual(a['intruding_nodes'],[LEGACY]);self.assertEqual(a['sections_with_intrusions'],13)
    def test_13_after_sections_free(self):
        b=section_screen(self.derived);self.assertEqual(b['intruding_nodes'],[]);self.assertEqual(b['sections_with_intrusions'],0)
    def test_dont_confuse_section_with_full_scene_clearance(self):self.assertFalse(section_screen(self.derived)['continuous_sweep_certified'])

if __name__=='__main__':unittest.main()
