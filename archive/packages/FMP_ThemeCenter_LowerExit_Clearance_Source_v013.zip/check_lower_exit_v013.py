"""Actual mesh-clearance cross-section screen. Portal-frame trim is excluded by 3cm inset.

This does NOT constitute continuous body clearance or a historic pose solution.
"""
from __future__ import annotations
import hashlib
import io
import json
import zipfile
from pathlib import Path
import numpy as np
import trimesh
from shapely.geometry import LineString, box
from repair_lower_exit_v013 import SOURCE_SHA256,LEGACY,patch_source,sha

HEAD='INTERPRETIVE_LOWER_PORTAL_HEAD'
NORTH='INTERPRETIVE_LOWER_PORTAL_JAMB_N'
SOUTH='INTERPRETIVE_LOWER_PORTAL_JAMB_S'
SILL='INTERPRETIVE_LOWER_PORTAL_SILL_GUIDE'

def world_mesh(s,name):
    T,geom=s.graph.get(name)
    if geom is None:raise ValueError('node has no mesh: '+name)
    out=s.geometry[geom].copy()
    out.apply_transform(T)
    return out

def section_screen(blob,positions=13,inset_m=.03):
    scene=trimesh.load(io.BytesIO(blob),force='scene',file_type='glb')
    # No arbitrary coordinates: derive x interval, Y, Z of actual opening from modeled frames.
    head=world_mesh(scene,HEAD).bounds
    north=world_mesh(scene,NORTH).bounds
    south=world_mesh(scene,SOUTH).bounds
    sill=world_mesh(scene,SILL).bounds
    lo=[north[1,2]+inset_m,sill[1,1]+inset_m]
    hi=[south[0,2]-inset_m,head[0,1]-inset_m]
    if lo[0]>=hi[0] or lo[1]>=hi[1]:raise ValueError('no remaining clear opening')
    region=box(lo[0],lo[1],hi[0],hi[1])
    xx=np.linspace(head[0,0]+1e-4,head[1,0]-1e-4,positions)
    rows=[]
    for x in xx:
        items=[]
        for name in scene.graph.nodes:
            T,g=scene.graph.get(name)
            if g is None:continue
            gmesh=scene.geometry[g]
            bb=trimesh.transform_points(gmesh.bounds,T)
            lower,upper=bb.min(0),bb.max(0)
            if not(lower[0] < x < upper[0] and lower[1]<hi[1] and upper[1]>lo[1] and lower[2]<hi[0] and upper[2]>lo[0]):
                continue
            mesh=world_mesh(scene,name)
            sections=trimesh.intersections.mesh_plane(mesh,plane_normal=[1,0,0],plane_origin=[float(x),0,0])
            total=0.0;count=0
            for seg in sections:
                length=LineString([seg[0,[2,1]],seg[1,[2,1]]]).intersection(region).length
                if length>1e-6:
                    total+=length;count+=1
            if total>1e-6:items.append({'node':name,'count':count,'total_intersection_length_m':round(total,6)})
        rows.append({'x_m':round(float(x),6),'intrusions':items})
    return {'frame':'v005 local Y-up metres UNREGISTERED','opening_interior_inset_m':inset_m,
      'opening_x_interval_m':[float(head[0,0]),float(head[1,0])],
      'opening_clear_y_m':[lo[1],hi[1]],'opening_clear_z_m':[lo[0],hi[0]],
      'sample_sections':len(rows),'sections_with_intrusions':sum(bool(x['intrusions']) for x in rows),
      'intruding_nodes':sorted({x['node'] for r in rows for x in r['intrusions']}),
      'details':rows,'continuous_sweep_certified':False}


def main(source_zip,derived_glb,output):
    with zipfile.ZipFile(source_zip) as z:original=z.read('FMP_ThemeCenter_Assembled_Runtime_v005.glb')
    if sha(original)!=SOURCE_SHA256:raise ValueError('source hash mismatch')
    after=Path(derived_glb).read_bytes()
    before=section_screen(original);after_report=section_screen(after)
    if before['intruding_nodes']!=[LEGACY]:raise ValueError('unexpected original opening intrusions')
    if after_report['intruding_nodes']:raise ValueError('opening still obstructed by derived mesh')
    r={'schema':'fmp.theme-center.lower-exit-cross-section-audit.v013','source_sha256':SOURCE_SHA256,
       'derived_sha256':sha(after),'before':before,'after':after_report,
       'status':'13_OF_13_MODEL_LOCAL_CROSS_SECTIONS_CLEAR_AFTER_RUNTIME_SELECTION',
       'historical_door_location_verified':False,'full_body_sweep_done':False,
       'source_model_preserved':True}
    Path(output).write_text(json.dumps(r,indent=2)+'\n')
    return r

if __name__=='__main__':
    import argparse
    a=argparse.ArgumentParser();a.add_argument('--source-zip',required=True);a.add_argument('--derived-glb',required=True);a.add_argument('--report',required=True)
    x=a.parse_args();print(main(x.source_zip,x.derived_glb,x.report)['status'])
