"""Non-destructive GLB runtime-branch repair for FMP v005.

This is NOT historical as-built correction. Disables only the conflicting old
PROVISIONAL_UPPER_EXIT_STAIR mesh binding in a new derived GLB, retaining all
original geometry bytes and nodes. Source GLB and all print masters stay intact.
"""
from __future__ import annotations
import hashlib
import io
import json
import struct
import zipfile
from pathlib import Path

SOURCE_SHA256 = 'de38fdd5294285afd92dbb6be0a9d4e564c52bacd588a9fd116c9e1e35f06439'
LEGACY = 'PROVISIONAL_UPPER_EXIT_STAIR'
EXPECTED_NODE_INDEX = 498
EXPECTED_MESH_INDEX = 643
TARGET = 'PROVISIONAL_UpperReturnStair_'


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def chunks(glb: bytes):
    if len(glb)<20 or struct.unpack_from('<4sI',glb,0) != (b'glTF',2):
        raise ValueError('not GLB 2')
    if struct.unpack_from('<I',glb,8)[0]!=len(glb):
        raise ValueError('invalid GLB total size')
    pos = 12
    out=[]
    while pos < len(glb):
        if pos+8>len(glb):raise ValueError('incomplete chunk header')
        size, kind = struct.unpack_from('<I4s',glb,pos)
        pos += 8
        if size % 4 or pos + size > len(glb):raise ValueError('bad GLB chunk length')
        out.append((kind,glb[pos:pos+size]))
        pos+=size
    if len(out)!=2 or out[0][0]!=b'JSON' or out[1][0]!=b'BIN\x00':
        raise ValueError('expected standard two-chunk GLB')
    return out


def unpack_json(glb: bytes):
    return json.loads(chunks(glb)[0][1].rstrip(b' \x00'))


def rebuild_glb(json_doc: dict, old_bin: bytes) -> bytes:
    raw = json.dumps(json_doc,separators=(',',':'),ensure_ascii=False).encode('utf-8')
    raw += b' ' * (-len(raw)%4)
    if len(old_bin)%4:raise ValueError('original BIN misaligned')
    total = 12+8+len(raw)+8+len(old_bin)
    return b''.join((struct.pack('<4sII',b'glTF',2,total),struct.pack('<I4s',len(raw),b'JSON'),raw,struct.pack('<I4s',len(old_bin),b'BIN\x00'),old_bin))


def patch_source(source:bytes):
    if sha(source)!=SOURCE_SHA256:raise ValueError('wrong model source SHA-256')
    parts=chunks(source)
    document=unpack_json(source)
    nodes=document.get('nodes',[])
    identified=[(i,n) for i,n in enumerate(nodes) if n.get('name')==LEGACY]
    if len(identified)!=1:raise ValueError('legacy stair not unique')
    index, node=identified[0]
    if index!=EXPECTED_NODE_INDEX or node.get('mesh')!=EXPECTED_MESH_INDEX:
        raise ValueError('legacy node/mesh identity mismatch')
    stairs=[n for n in nodes if n.get('name','').startswith(TARGET)]
    if len(stairs)!=23:raise ValueError('expected 23 replacement tread proxies')
    before={'node_index':index,'original_mesh_index':node['mesh'],
       'original_node_data':json.loads(json.dumps(node))}
    node.pop('mesh')
    node.setdefault('extras',{}).setdefault('fmp',{})['runtime_selection_v013']='LEGACY_MESH_BINDING_DISABLED__RETAINED_IN_BIN'
    node['extras']['fmp']['selection_status']='PROVISIONAL_COLLISION_REPAIR_NOT_HISTORICAL'
    derived=rebuild_glb(document,parts[1][1]);v=unpack_json(derived)
    if v['nodes'][index].get('mesh') is not None:raise AssertionError('legacy still active')
    if len(v['nodes'])!=len(nodes) or len(v['meshes'])!=len(document['meshes']):raise AssertionError('asset counts drifted')
    if chunks(derived)[1][1]!=parts[1][1]:raise AssertionError('binary geometry altered')
    return derived,before


def run(zip_path:Path,out_path:Path,report_path:Path):
    with zipfile.ZipFile(zip_path) as z:src=z.read('FMP_ThemeCenter_Assembled_Runtime_v005.glb')
    derived,restore=patch_source(src)
    out_path.write_bytes(derived)
    data={'schema':'fmp.theme-center.runtime-branch.v013','source_sha256':SOURCE_SHA256,
      'source_size_bytes':len(src),'derived_sha256':sha(derived),'derived_size_bytes':len(derived),
      'source_bin_sha256':sha(chunks(src)[1][1]),'derived_bin_sha256':sha(chunks(derived)[1][1]),
      'source_mesh_node':LEGACY,'original_binding':restore,
      'new_active_23_treads':23,'historical_geometry_certified':False,
      'historical_source_changed':False,'full_scene_capsule_sweep_done':False,
      'unreal_native_tested':False,'readme':'Use this derivative ONLY with current provisional upper-exit v012 cheek overlay, never as a certified historical stair.'}
    report_path.write_text(json.dumps(data,indent=2)+'\n')
    return data

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--source-zip',required=True);p.add_argument('--out-glb',required=True);p.add_argument('--report',required=True)
    a=p.parse_args();print(json.dumps(run(Path(a.source_zip),Path(a.out_glb),Path(a.report)),indent=2))
