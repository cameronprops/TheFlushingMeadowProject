import json, unittest, copy, pathlib
from reconcile_girder_sources import audit
P=pathlib.Path(__file__).parent
class TestEvidenceGate(unittest.TestCase):
 @classmethod
 def setUpClass(cls): cls.base=json.loads((P/'STEEL_SOURCE_RECONCILIATION_v004.json').read_text())
 def test_valid_sources_gate_review(self): self.assertEqual(audit(self.base)['status'],'EVIDENCE_REVIEW_REQUIRED')
 def test_no_asbuilt_depth_claim(self): self.assertFalse(audit(self.base)['actual_asbuilt_girder_depth_certified'])
 def test_concrete_and_steel_separate(self): self.assertEqual(len(audit(self.base)['separate_structural_systems']),6)
 def test_actual_model_unmodified(self): self.assertFalse(audit(self.base)['runtime_mesh_replacement_authorized'])
 def test_period_page_anchor(self):
  d=copy.deepcopy(self.base);d['sources'][1]['pdf_page_1based']=55;self.assertIn('MISSING_PRIMARY_PAGE_ANCHOR',audit(d)['errors'])
 def test_reject_wrong_depth_authority(self):
  d=copy.deepcopy(self.base);d['sources'][1]['claim_status']='VERIFIED_AS_BUILT';self.assertIn('DESIGN_DEPTH_AUTHORITY_CONFLICT',audit(d)['errors'])
 def test_reject_conflated_concrete_and_steel(self):
  d=copy.deepcopy(self.base);d['sources'][0]['claims']['concrete_foundation_ring']=False;self.assertIn('CONCRETE_AND_STEEL_GIRDER_CONFLATED',audit(d)['errors'])
 def test_reject_unauthorized_released_mesh(self):
  d=copy.deepcopy(self.base);d['structural_geometry_released']=True;self.assertIn('UNAUTHORIZED_GEOMETRY_RELEASE',audit(d)['errors'])
 def test_reject_unsupported_stereo(self):
  d=copy.deepcopy(self.base);d['sources'][3]['matched_rivet_stiffener_correspondences']=4;self.assertIn('UNREVIEWED_STEREO_CORRESPONDENCES',audit(d)['errors'])
 def test_reject_same_stage(self):
  d=copy.deepcopy(self.base);d['sources'][3]['scene_stage']=d['sources'][2]['scene_stage'];self.assertIn('PHOTO_CONSTRUCTION_STAGE_NOT_DISTINGUISHED',audit(d)['errors'])
 def test_depth_delta(self): self.assertAlmostEqual(audit(self.base)['design_minus_runtime_vertical_section_m'],2.0424,places=6)
 def test_period_truss_counts(self):
  d=copy.deepcopy(self.base);d['sources'][0]['claims']['meridian_trusses']=31;self.assertIn('TRUSS_MEMBER_COUNT_CONFLICT',audit(d)['errors'])
if __name__=='__main__': unittest.main()
