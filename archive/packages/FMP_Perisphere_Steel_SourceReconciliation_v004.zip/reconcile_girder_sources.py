#!/usr/bin/env python3
"""FMP structural source gate: design vs historical construction vs model proxy.

No geometry generation, no assertions about unseen photo pixels. Python stdlib.
"""
import json, pathlib, sys
from decimal import Decimal

P = pathlib.Path(__file__).resolve().parent
FEET_PER_M = Decimal('1') / Decimal('0.3048')

def audit(evidence):
    src = {x['id']: x for x in evidence['sources']}
    f1 = src['AR_1938_PAGE_67']; f2 = src['AR_1938_PAGE_96']
    photos = [src['DRUM_ASSEMBLY_PHOTO'], src['DRUM_INSTALLED_PHOTO']]
    errs = []
    if f1['pdf_page_1based'] != 27 or f2['pdf_page_1based'] != 56:
        errs.append('MISSING_PRIMARY_PAGE_ANCHOR')
    if f1['original_pdf_sha256'] != f2['original_pdf_sha256'] or len(f1['original_pdf_sha256']) != 64:
        errs.append('PRIMARY_SOURCE_IDENTITY_CONFLICT')
    if f1['claims']['steel_ring_diameter_ft'] != 72 or f2['claims']['steel_ring_diameter_ft'] != 72:
        errs.append('STEEL_RING_DIAMETER_DRIFT')
    if f2['claims']['steel_ring_depth_ft'] != 8 or f2['claim_status'] != 'PERIOD_FINAL_DESIGN_NOT_ASBUILT_SURVEY':
        errs.append('DESIGN_DEPTH_AUTHORITY_CONFLICT')
    if f1['claims']['concrete_foundation_ring'] is not True or f1['claims']['upper_steel_ring'] is not True:
        errs.append('CONCRETE_AND_STEEL_GIRDER_CONFLATED')
    if f1['claims']['column_count'] != 8 or f1['claims']['meridian_trusses'] != 32 or f1['claims']['horizontal_trusses'] != 15:
        errs.append('TRUSS_MEMBER_COUNT_CONFLICT')
    if not all(x['photo_pixel_sha256'] and len(x['photo_pixel_sha256']) == 64 for x in photos):
        errs.append('PHOTO_DERIVATIVE_HASH_MISSING')
    if photos[0]['scene_stage'] == photos[1]['scene_stage']:
        errs.append('PHOTO_CONSTRUCTION_STAGE_NOT_DISTINGUISHED')
    if any(x.get('matched_rivet_stiffener_correspondences',0)>0 for x in photos):
        # Must be a separate reviewed correspondence register with physical member IDs.
        if not evidence.get('independent_3d_landmark_register'):
            errs.append('UNREVIEWED_STEREO_CORRESPONDENCES')
    if evidence.get('metric_camera_solved', False) or evidence.get('structural_geometry_released', False):
        errs.append('UNAUTHORIZED_GEOMETRY_RELEASE')
    depth_ft = Decimal(str(f2['claims']['steel_ring_depth_ft']))
    proxy_m = Decimal(str(evidence['runtime_proxy']['vertical_section_m']))
    depth_m = depth_ft * Decimal('0.3048')
    ratio = proxy_m / depth_m
    result = {
        'status': 'EVIDENCE_REVIEW_REQUIRED' if not errs else 'BLOCKED',
        'errors': errs,
        'separate_structural_systems': ['528 piles', 'concrete foundation ring', 'eight steel columns',
                                        '72ft steel drum girder', '32 meridian trusses', '15 horizontal trusses'],
        'steel_ring_diameter_ft':72,
        'steel_ring_depth_ft_period_design': float(depth_ft),
        'steel_ring_depth_m_period_design':float(depth_m),
        'runtime_proxy_vertical_section_m':float(proxy_m),
        'runtime_proxy_vertical_section_ft':float(proxy_m * FEET_PER_M),
        'design_minus_runtime_vertical_section_m':float(depth_m - proxy_m),
        'runtime_to_design_depth_ratio':float(ratio),
        'same_photo_stereo_3d_correspondences':0,
        'actual_asbuilt_girder_depth_certified':False,
        'independent_camera_calibrations':0,
        'runtime_mesh_replacement_authorized':False,
        'photo_stage_pair_fits_same_camera':False,
        'evidence_classes':{'72ft steel ring diameter':'period published as-finally-constructed',
            '8ft steel girder depth':'period final design, as-built recheck pending',
            '1.299ft toroidal ring':'derived measured mesh representation only',
            'two photographic construction stages':'photo record; not calibrated stereo'}
    }
    return result

if __name__ == '__main__':
    data = json.loads((P/'STEEL_SOURCE_RECONCILIATION_v004.json').read_text())
    result=audit(data)
    (P/'AUDIT_REPORT_v004.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    sys.exit(0 if not result['errors'] else 2)
