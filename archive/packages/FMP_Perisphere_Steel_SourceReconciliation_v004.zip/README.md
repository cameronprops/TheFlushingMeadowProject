# FMP 1938 Perisphere steel-source reconciliation v004

**Status:** implemented, 12/12 tests passed; historical girder depth **NOT verified as built**. No GLB, editable Rhino master, print assets or historical dimensions modified.

## New primary evidence reviewed

The FMP Google Drive archive already held an original issue copy, `AR-1938-11.pdf` (50,653,133 bytes, SHA-256 `c3196f82ce92a3b364fb1bc8b33736535fe5d1b26e7c8a40c1fb615e293339f3`, Drive ID `1omQHXfoOz6PhyJYNfpIaYBJLxOTCYr-Q`). Scanned source pages were read and visually inspected with page renders; the source issue itself is NOT republished in this public code package.

- **Print page 67, PDF page 27**, Theme Center description: calls the arrangement **“as finally constructed”** and describes 528 piles, a concrete foundation ring, eight columns, a 72-foot steel ring girder, 32 meridian trusses and 15 horizontal trusses. Several of these components are distinct and must be independently modeled.
- **Print page 96, PDF page 56**, *Superstructure*: gives an **8-foot-deep, 72-foot-diameter** steel ring in the “final design”. The paragraph also retains proposed Trylon dimensions **700 ft tall / 500 ft framed**, which conflict with separately documented 610 ft / 480 ft built dimensions. The eight-foot depth remains **period engineering design evidence pending as-built verification**, not a directly surveyed finished ring section.

## Second actual construction view recovered

A reproduction attributed to NYPL Digital Collections is the second real image: item UUID `5e66b3e8-9fb5-d471-e040-e00a180654d7`, at a 541×691-pixel derivative with decoded-pixel SHA-256 `4103ed4ab6318f27b5e4ff9a5af79374358b7b53470a8b84a53caf92d8c153e5`. It shows the installed drum on raised columns at left of an unfinished Trylon. First image (the earlier overhead assembly photo) is the 673×520 image, pixel SHA-256 `6d5fdba8ff455d0d10c44ed0a404cc318d80d128ac47b0f17d791cfdb860175c`. Both images are source-linked, **not copied** into the package due uncertain image rights.

No physical rivet/stiffener feature has been unambiguously matched across the two photographs and no camera extrinsics or intrinsics have been calibrated. These two construction phases are not a stereo pair, and photos are insufficient to certify girder plate heights. Do not assume the radial construction beams are permanent bracing.

## Modeling interpretation

Measured v005 runtime `Perisphere_Support_Ring` section is **0.396 m / 1.2992 ft**. Eight feet is 2.4384 m; the 2.0424-m vertical difference represents 83.76% of the period design depth. This flags a **missing or separate structural representation** candidate, but does not prove the named torus was intended to model the drum girder. Keep the support-ring proxy, concrete collar, columns, and drum girder as separate logical objects. Only an independently examined as-built drawing or a valid calibrated photo pair can promote the full drum into the historical master.

## Reproduction

From this directory run:

    python reconcile_girder_sources.py
    python -m unittest discover -p 'test_*.py' -v

The audit is read-only and produces `AUDIT_REPORT_v004.json`. It rejects inconsistent citations, phase conflation, missing photo fingerprints, unsupported stereo promotion, changed structural counts and automatic historical geometry release.

## Source URLs

- Period issue: https://www.worldsfairphotos.com/nywf39/articles/design-trends.pdf (excerpt mirror; actual source issue archived in FMP Drive)
- First overhead photo: https://drivingfordeco.com/wp-content/uploads/2019/04/Drum-Girder.jpg
- Second NYPL photo original item reference: https://digitalcollections.nypl.org/items/5e66b3e8-9fb5-d471-e040-e00a180654d7
- Second reproduced derivative: https://drivingfordeco.com/wp-content/uploads/2019/04/nypl.digitalcollections.5e66b3e8-9fb5-d471-e040-e00a180654d7.001.w.jpg
- FMP issue: https://github.com/cameronprops/TheFlushingMeadowProject/issues/21

**Game Development Studio:** read-only information/model-role review. Native `game-dev` CLI and Unreal geometry admission not performed.
