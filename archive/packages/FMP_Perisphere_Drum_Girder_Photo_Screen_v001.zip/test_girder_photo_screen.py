import copy
import json
import unittest
from pathlib import Path
from girder_photo_screen import test_girder_dimensions

OBS = json.loads((Path(__file__).parent/'observations_v001.json').read_text())

class TestPhotoScreen(unittest.TestCase):
    def test_calculations(self):
        r = test_girder_dimensions(OBS)
        thin = r['candidate_depths']['v005_runtime_proxy']['required_vertical_vs_horizontal_projection_gain']
        full = r['candidate_depths']['period_article_girder']['required_vertical_vs_horizontal_projection_gain']
        self.assertAlmostEqual(thin[0], 75*72/(635*1.3), 10)
        self.assertAlmostEqual(thin[1], 100*72/(580*1.3), 10)
        self.assertAlmostEqual(full[0], 75*72/(635*8), 10)
        self.assertFalse(r['as_built_girder_depth_certified'])
        self.assertFalse(r['historic_geometry_update_allowed'])
    def test_invalid_source_rejected(self):
        x=copy.deepcopy(OBS);x['source_id']='unknown';self.assertRaises(ValueError,test_girder_dimensions,x)
    def test_invalid_ranges_rejected(self):
        x=copy.deepcopy(OBS);x['front_face_height_px_range']=[100,75];self.assertRaises(ValueError,test_girder_dimensions,x)
    def test_promotion_rejected(self):
        x=copy.deepcopy(OBS);x['automatically_promote_geometry']=True;self.assertRaises(ValueError,test_girder_dimensions,x)
    def test_unsupported_annotation_state_rejected(self):
        x=copy.deepcopy(OBS);x['annotation_evidence']='VERIFIED_BY_CAMERA';self.assertRaises(ValueError,test_girder_dimensions,x)
    def test_nonpositive_depth_rejected(self):
        x=copy.deepcopy(OBS);x['candidate_depths_ft']['bad']=0;self.assertRaises(ValueError,test_girder_dimensions,x)

if __name__ == '__main__':unittest.main()
