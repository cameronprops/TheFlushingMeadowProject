"""FMP source-gated perspective sensitivity test for the 1938 Perisphere drum girder.

Does not solve camera intrinsics, 3D coordinates, or approve historical geometry.
"""
import argparse
import json
import math
from pathlib import Path


def test_girder_dimensions(obs):
    if obs.get('source_id') != 'DRUM_GIRDER_PHOTO_1938_REPRO':
        raise ValueError('Source identity mismatch')
    w = obs['apparent_diameter_px_range']
    h = obs['front_face_height_px_range']
    dia = obs['period_ring_centerline_diameter_ft']
    if not (len(w) == len(h) == 2 and 0 < w[0] <= w[1] and 0 < h[0] <= h[1] and dia > 0):
        raise ValueError('Invalid, nonpositive or inverted range')
    if obs.get('automatically_promote_geometry', False):
        raise ValueError('Model promotion is not authorized')
    if obs.get('annotation_evidence') != 'VISUAL_PIXEL_RANGE_ESTIMATE_UNCALIBRATED':
        raise ValueError('Annotation is not calibrated')
    candidates = {}
    for name, depth_ft in obs['candidate_depths_ft'].items():
        if depth_ft <= 0 or not math.isfinite(depth_ft):
            raise ValueError('Nonpositive candidate depth')
        # K = [observed vertical pixels / depth ft] / [observed width pixels / 72 ft]
        # This is NOT a recovered camera correction: K is the *necessary* correction.
        low = h[0] * dia / (w[1] * depth_ft)
        high = h[1] * dia / (w[0] * depth_ft)
        candidates[name] = dict(required_vertical_vs_horizontal_projection_gain=[low, high],
                                depth_ft=depth_ft)
    return {
        'status': 'PHOTO_HYPOTHESIS_SCREEN_NOT_CALIBRATED',
        'source_id': obs['source_id'],
        'period_reference_diameter_ft': dia,
        'candidate_depths': candidates,
        'image_scale_from_reference_px_per_ft_range': [w[0]/dia, w[1]/dia],
        'pixel_estimates_independently_verified': False,
        'camera_intrinsics_solved': False,
        'camera_extrinsics_solved': False,
        'perspective_gain_bounded_by_photogrammetry': False,
        'source_photo_rights_cleared': False,
        'as_built_girder_depth_certified': False,
        'historic_geometry_update_allowed': False,
        'model_coordinate_registration_solved': False,
        'notes': [
            'The x-span includes plate flanges and is not confirmed as the historic 72-ft centerline.',
            'Hand-estimated pixel ranges are a sensitivity screen, NOT a physically calibrated scan.',
            'Necessary K interval is not a probabilistic confidence interval.',
            'Independent construction views or original camera data and identified radial/vertical controls are required.',
            'The existing 1.3-ft runtime ring may be a location proxy rather than the historical drum girder.'
        ]}


def main():
    p = argparse.ArgumentParser()
    p.add_argument('observations', type=Path)
    p.add_argument('--out', type=Path)
    args = p.parse_args()
    result = test_girder_dimensions(json.loads(args.observations.read_text()))
    output = json.dumps(result, indent=2) + '\n'
    if args.out:
        args.out.write_text(output)
    else:
        print(output)

if __name__ == '__main__':
    main()
