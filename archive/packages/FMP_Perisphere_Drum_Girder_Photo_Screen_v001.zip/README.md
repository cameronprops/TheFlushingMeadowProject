# Perisphere drum girder: actual construction photo sensitivity v001

**Status: PARTIALLY VALIDATED PHOTO SCREEN; historical depth NOT certified.** This study uses a real period photograph of the riveted Perisphere drum girder, as reproduced by Driving for Deco. The image is not bundled: rights have not been cleared. Source URL, 673×520 derivative dimension and Wolfram pixel-array checksum are in `observations_v001.json`.

## Known versus inferred

- **Period documented (design):** the *Architectural Record* / *Design Trends* description reports a 72-foot-diameter ring, 8 feet deep, supported by eight columns and receiving 32 meridian trusses. The same period publication contains some earlier proposed values elsewhere. The 8-foot depth is not yet independently confirmed from a final as-built drawing.
- **Runtime mesh derived:** the named `Perisphere_Support_Ring` in FMP assembled v005 has a vertical section ~1.30 ft and a ring centerline diameter approximately 72 ft. The ring may be a placeholder/alignment tube, not the historical drum girder.
- **Image observations provisional:** the reproduced photograph shows a very deep riveted vertical steel shell at the front. Rough, deliberately broad screen-space ranges are 580–635 pixels across the visible plate/ring, and 75–100 pixels vertically across the front steel face. These are **hand-estimated ranges**, not registered image points or calibrated image measurements. Apparent width covers flanges, not necessarily exactly the 72-foot girder centerline diameter.

## Wolfram verified necessary perspective-scale ratio

For a candidate girder depth `H` feet, ring diameter `D = 72` feet and observed image width `W` pixels and near-face height `P` pixels, the necessary local vertical relative to horizontal projection gain is:

`K = (P/H)/(W/D) = 72 P/(H W)`.

The interval of K is purely a sensitivity range from the approximate pixel bounds and **is not a confidence interval**.

| Candidate | Required K over ranges | Interpretation |
|---|---|---|
| `H=1.3 ft` thin v005 ring | `6.54–9.55×` | Requires very large vertical pixel scaling relative to the ring span; difficult to reconcile with visible perspective, but cannot be formally ruled out from this calculation alone |
| `H=8 ft` 1938 period steel girder | `1.06–1.55×` | More consistent with ordinary viewpoint-dependent projection, but does not prove exact 8-foot as-built depth |

Wolfram Language evaluator independently confirmed these numeric intervals from the observations.

## How to run

`python3 girder_photo_screen.py observations_v001.json --out RESULT.json`

`python3 -m unittest -v test_girder_photo_screen.py`

## What locks the dimensions next

1. Obtain rights-appropriate original NYPL/MCNY steel construction scans. Confirm sheet/negative date and photograph's girder identity.
2. Annotate paired top/bottom points along multiple **the same vertical steel stiffeners**, and corresponding positions around the ring's top circle, with explicit pixel uncertainties and source checksum.
3. Fit an actual camera model using known 72-ft ring geometry and independently test held-out top/vertical features. Cross-check from a second camera viewpoint. Propagate uncertainty in the outer-vs-centerline radius and lens model.
4. Compare full-length ring girder vertical extent and meridian endpoints from CAD against period plans. Distinguish permanent structure from erection equipment and scene proxies.
5. Only then approve a separate parametric steel girder master or derivative. Never modify the historic master or validated runtime v005 by assumption.

**Game Development Studio:** This is a read-only geometry-evidence gate. No model change, runtime import, collision test or GPU validation performed. Preserve WF0002 identifiers and original source files.
