#!/usr/bin/env python3
"""Evidence-only single-photo girder sensitivity analysis. Never releases CAD geometry.

Coordinate system: original 673x520 JPEG pixel grid, origin top left.
Assumes circular horizontal upper flange, approximately parallel vertical web,
weak-perspective ellipse. Perspective magnification and flange-to-centerline
mismatch remain independent UNSOLVED nuisance parameters.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import cv2
import numpy as np

EXPECTED_SOURCE_ID='PHOTO_1938_PERISPHERE_DRUM_GIRDER_DFD'
ALLOWED_STATE='CONSTRUCTION_EXPOSED_DRUM_ASSEMBLY_1938_APPROX'


def audit_input(info):
    assert info['source_id']==EXPECTED_SOURCE_ID, 'unexpected image ID'
    assert info['image_size_px']==[673,520], 'image dimension drift'
    assert info['source_image_uri'].startswith('https://drivingfordeco.com/wp-content/uploads/2019/04/Drum-Girder.jpg'), 'source URI drift'
    assert info['state']==ALLOWED_STATE
    pts=np.array(info['rim_points_px'],dtype=np.float64)
    pairs=np.array(info['visible_front_web_stiffener_pairs_px'],dtype=np.float64)
    assert pts.ndim==2 and pts.shape[1]==2 and len(pts)>=9
    assert pairs.ndim==3 and pairs.shape[1:]==(2,2) and len(pairs)>=3
    assert np.all(np.isfinite(pts)) and np.all(np.isfinite(pairs))
    assert np.all(pts[:,0]>=0) and np.all(pts[:,0]<673)
    assert np.all(pts[:,1]>=0) and np.all(pts[:,1]<520)
    assert np.all(pairs[:,:,0]>=0) and np.all(pairs[:,:,0]<673)
    assert np.all(pairs[:,:,1]>=0) and np.all(pairs[:,:,1]<520)
    assert np.all(pairs[:,1,1]>pairs[:,0,1]), 'web bottom below top required'
    assert info['known_nominal_ring_diameter_ft']>0
    assert info['pixel_annotation_sigma_px']>0
    assert info['structural_section_hypotheses_ft']==[1.3,8]
    assert info['film_or_photo_pixel_copy_archived'] is False


def fit_top_ellipse(points):
    p=np.asarray(points,dtype=np.float32)
    if len(p)<5:
        raise ValueError('ellipse needs five or more points')
    if cv2.contourArea(cv2.convexHull(p))<=1500:
        raise ValueError('degenerate points')
    (x,y),(a,b),rot=cv2.fitEllipse(p)
    major,minor=max(a,b),min(a,b)
    if major<=0 or minor<=0 or minor/major>=0.95:
        raise ValueError('unusable apparent ellipse')
    return {'center_px':[float(x),float(y)],'major_axis_px':float(major),
            'minor_axis_px':float(minor),'opencv_rotation_deg':float(rot),
            'minor_major_ratio':float(minor/major),
            'apparent_elevation_from_horizontal_deg':float(math.degrees(math.asin(minor/major))),
            'weak_perspective_vertical_projection_factor':float(math.sqrt(1-(minor/major)**2))}


def screen(info, jitter_samples=1000,seed=1938):
    audit_input(info)
    e=fit_top_ellipse(info['rim_points_px'])
    pairs=np.asarray(info['visible_front_web_stiffener_pairs_px'],dtype=np.float64)
    spans=(pairs[:,1,1]-pairs[:,0,1])
    measured=float(np.median(spans))
    pxft=e['major_axis_px']/info['known_nominal_ring_diameter_ft']
    vert_scale=pxft*e['weak_perspective_vertical_projection_factor']
    boosts=info['perspective_gain_sensitivity_only']
    outputs={str(k):{'depth_ft_conditional':float(measured/(vert_scale*k)),
                     'required_face_pixels_for_8_ft':float(8*vert_scale*k),
                     'required_face_pixels_for_1p3_ft':float(1.3*vert_scale*k)} for k in boosts}
    needed={str(h):float(measured/(vert_scale*h)) for h in info['structural_section_hypotheses_ft']}
    rng=np.random.default_rng(seed)
    values={str(k):[] for k in boosts}
    for i in range(jitter_samples):
        jitter=rng.normal(0.,info['pixel_annotation_sigma_px'],size=(len(info['rim_points_px']),2))
        ep=fit_top_ellipse(np.asarray(info['rim_points_px'],dtype=float)+jitter)
        pairpert=pairs + rng.normal(0.,info['pixel_annotation_sigma_px'],size=pairs.shape)
        h=np.median(pairpert[:,1,1]-pairpert[:,0,1])
        if h<=0:continue
        sc=ep['major_axis_px']/info['known_nominal_ring_diameter_ft']*ep['weak_perspective_vertical_projection_factor']
        for boost in boosts:values[str(boost)].append(float(h/(sc*boost)))
    sensitivity={k:{'annotation_only_quantiles_05_50_95_ft':[round(float(t),3) for t in np.quantile(v,[0.05,0.5,0.95])],
                    'n':len(v)} for k,v in values.items()}
    return {'status':'PROVISIONAL_RIM_FIT_NOT_METRIC_CAMERA_CALIBRATION',
        'source_id':info['source_id'],
        'source_image_url':info['source_image_uri'],
        'source_decoded_pixel_sha256_wolfram':info['decoded_pixel_sha256_wolfram'],
        'camera_intrinsics_measured':False,'camera_pose_solved':False,
        'as_built_girder_height_certified':False,'historical_geometry_release_allowed':False,
        'flange_centerline_difference_measured':False,
        'annotation_review_required':True,'ellipse':e,
        'web_spans_px':[float(a) for a in spans], 'web_span_median_px':measured,
        'baseline_vertical_px_per_foot':float(vert_scale),
        'perspective_gain_scenario_ft':outputs,
        'relative_gain_needed_for_hypotheses':needed,
        'annotation_jitter_sigma_px':info['pixel_annotation_sigma_px'],
        'annotation_only_sensitivity':sensitivity,
        'systematics_not_bounded':['perspective depth-dependent scale', 'lens distortion',
            '72-ft historical diameter centerline vs photographed outside flange',
            'selection of physically corresponding top and bottom steel flange edges',
            'not all rim picks are guaranteed on the same ideal circle',
            'construction state may predate completed assembly'],
        'next_gate':'independent original negative(s), calibrated camera and paired physical steel landmarks required'}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input',required=True)
    ap.add_argument('--out',required=True)
    ap.add_argument('--iterations',type=int,default=2000)
    a=ap.parse_args()
    info=json.loads(Path(a.input).read_text())
    result=screen(info,a.iterations)
    Path(a.out).write_text(json.dumps(result,indent=2)+'\n')
    print(result['status'],result['ellipse']['major_axis_px'],result['ellipse']['minor_axis_px'])
    for k,scenario in result['perspective_gain_scenario_ft'].items():
        print('perspective gain',k,'depth ft',round(scenario['depth_ft_conditional'],3))

if __name__=='__main__': main()
