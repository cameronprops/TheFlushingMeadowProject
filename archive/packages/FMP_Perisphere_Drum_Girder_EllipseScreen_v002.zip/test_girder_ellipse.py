from pathlib import Path
import json
import copy
import unittest
import numpy as np
from measure_girder_ellipse import screen,fit_top_ellipse,audit_input

BASE = json.loads((Path(__file__).parent/'PHOTO_ANNOTATIONS_v002.json').read_text())

class StructuralPhotographGuardTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.r = screen(BASE, jitter_samples=120, seed=1938)
    def test_source_controls(self):
        self.assertEqual(BASE['image_size_px'],[673,520]);self.assertEqual(len(BASE['rim_points_px']),14)
    def test_provisional_not_cad(self):
        self.assertIs(self.r['historical_geometry_release_allowed'],False)
        self.assertIs(self.r['as_built_girder_height_certified'],False)
        self.assertIs(self.r['camera_pose_solved'],False)
    def test_ellipse_analytic_values(self):
        e=self.r['ellipse'];self.assertAlmostEqual(e['major_axis_px'],627.0433,places=2)
        self.assertAlmostEqual(e['minor_axis_px'],261.92154,places=2)
    def test_angle_and_span(self):
        self.assertTrue(23 < self.r['ellipse']['apparent_elevation_from_horizontal_deg'] <26)
        self.assertEqual(self.r['web_span_median_px'],81)
    def test_8ft_starts_near_nominal_scale(self):
        self.assertTrue(7<self.r['relative_gain_needed_for_hypotheses']['1.3']<9)
        self.assertTrue(1.0<self.r['relative_gain_needed_for_hypotheses']['8']<1.5)
    def test_perspective_sensitivity_monotonic(self):
        vals=[v['depth_ft_conditional'] for v in self.r['perspective_gain_scenario_ft'].values()]
        self.assertEqual(vals,sorted(vals,reverse=True))
    def test_deterministic_jitter(self):
        other=screen(BASE,jitter_samples=120,seed=1938)
        self.assertEqual(other['annotation_only_sensitivity'],self.r['annotation_only_sensitivity'])
    def test_bad_source_rejected(self):
        m=copy.deepcopy(BASE);m['source_id']='OTHER';self.assertRaises(AssertionError,audit_input,m)
    def test_point_outside_rejected(self):
        m=copy.deepcopy(BASE);m['rim_points_px'][3]=[900,44];self.assertRaises(AssertionError,audit_input,m)
    def test_stiffener_order_rejected(self):
        m=copy.deepcopy(BASE);m['visible_front_web_stiffener_pairs_px'][1][1][1]=20
        self.assertRaises(AssertionError,audit_input,m)
    def test_degenerate_ellipse_rejected(self):
        self.assertRaises(ValueError,fit_top_ellipse,[[i,0] for i in range(10)])
    def test_raw_photo_not_copied(self):
        self.assertIs(BASE['film_or_photo_pixel_copy_archived'],False)

if __name__=='__main__': unittest.main()
