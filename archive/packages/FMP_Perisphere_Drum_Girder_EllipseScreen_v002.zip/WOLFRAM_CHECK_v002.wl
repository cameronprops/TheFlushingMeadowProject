(* Reproducible independent mathematical check using measured parameters.
   All outputs are conditional on manually estimated image annotations and
   nominal 72-ft outer rim equivalence. No as-built claim. *)
ClearAll[FMPGirderPerspectiveSensitivity];
FMPGirderPerspectiveSensitivity[major_?NumericQ, minor_?NumericQ,
    apparentWeb_?NumericQ, nominalDia_?NumericQ, gains_List] :=
 Module[{elevation, baseline},
  If[major <= minor || minor <= 0 || nominalDia <= 0 ||
     apparentWeb <= 0 || !AllTrue[gains, NumericQ[#] && #>0 &],
     Return[<|"status"->"INVALID_SCREENING_INPUT"|>]];
  elevation = ArcSin[minor/major];
  baseline=(major/nominalDia) Cos[elevation];
  <|"status"->"HYPOTHESIS_ONLY",
    "apparent_elevation_deg"->N[elevation/Degree],
    "px_per_ft_baseline"->N[baseline],
    "depth_ft_by_relative_perspective_gain"->N[apparentWeb/(baseline #)&/@gains],
    "gain_for_8ft"->N[apparentWeb/(baseline 8)],
    "gain_for_1p3ft"->N[apparentWeb/(baseline 1.3)],
    "historical_geometry_release_allowed"->False|>];
FMPGirderPerspectiveSensitivity[627.0433349609375,261.9215393066406,81.,72.,
 {1.,1.15,1.3,1.45,1.6}]
